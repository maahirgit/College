#include <iostream>
using namespace std;
main()
{
    int i;
    for (i = 1; i <= 10; i++)
    {
        cout << i << endl;
    }
}
