//Write a C++ program to display “Hello World” on the screen.

#include<iostream>
using namespace std;
int main(){

    cout<<"Hello World"<<endl;

}