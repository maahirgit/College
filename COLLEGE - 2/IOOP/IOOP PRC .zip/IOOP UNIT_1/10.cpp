// Write a C++ program to demonstrate the use of comments.
#include<iostream>
using namespace std ;
int main(){
    
}