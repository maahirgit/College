// Write a C++ program to perform addition of two object variable into third object and
// return the same.
#include <iostream>
using namespace std;

class Number {
private:
    int num;
public:
    Number() : num(0) {}
    Number(int n) : num(n) {}

    Number operator+(Number n2) {
        Number result(num + n2.num);
        return result;
    }

    void display() {
        cout << num;
    }
};

int main() {
    Number n1(10), n2(20), n3;
    n3 = n1 + n2;
    cout << "n1 + n2 = ";
    n3.display();
    cout << endl;
    return 0;
}
