package X;

public class A1{
    public void msg(){
        System.out.println("Hello");
    }
}