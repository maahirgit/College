package A;

public class MyClass{
    public void display(){
        System.out.println("Hello from myclass");
    }
}