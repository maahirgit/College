package Y;
import X.*;
class B1{
    public static void main(String args[]){
        A1 obj = new A1();
        obj.msg();
    }
}