package B;
import A;

public class YourClass{
    public static void main(String args[]){
        MyClass m1 = new MyClass();
        m1.display();
    }
}