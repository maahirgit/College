// Question 2

class Calculate{
    int id = 1;
    String name = "Maahir";
    int std = 12;
}

class College{
    public static void main(String args[]){
        Calculate c1 = new Calculate();
        System.out.println(c1.id+" "+c1.name+" "+c1.std);
    }
}