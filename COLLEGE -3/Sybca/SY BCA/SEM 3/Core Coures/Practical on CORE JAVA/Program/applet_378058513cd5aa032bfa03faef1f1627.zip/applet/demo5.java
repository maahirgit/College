import javax.swing.*;
import java.awt.*;

class demo5
{
	public static void main(String args[])
	{
	JFrame frm1=new JFrame("DEMO3");
	frm1.setVisible(true);
	frm1.setSize(200,200);
	JButton btn1=new JButton(" SUM  ");
	JButton btn2=new JButton(" DIV   ");
	JLabel l1=new JLabel();//1
	JTextField t1=t1=new JTextField();
	JRadioButton r1=new JRadioButton("A) Male");    
	JRadioButton r2=new JRadioButton("B) Female");
	JCheckBox c1 = new JCheckBox("Java", true);  
	JCheckBox c2 = new JCheckBox("C++");  
	JTextArea area=new JTextArea("Welcome");  
	FlowLayout fl=(new FlowLayout(FlowLayout.LEFT));
	frm1.setLayout(fl);	
	frm1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ; 
	frm1.add(btn1);
	frm1.add(btn2);
	frm1.add(l1);	
	frm1.add(t1);
	frm1.add(r1);	
	frm1.add(r2);
	frm1.add(c1);	
	frm1.add(c2);
	frm1.add(area);	
	}
}
