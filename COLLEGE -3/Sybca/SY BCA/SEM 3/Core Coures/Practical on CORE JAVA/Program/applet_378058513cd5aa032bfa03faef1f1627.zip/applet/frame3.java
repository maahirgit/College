import javax.swing.*;


class frame3 
{
	
	public static void main(String args[])
	{
		JFrame f=new JFrame("Window 1 DEMO");
		f.setSize(400,400);
		f.setVisible(true);
		f.setLocation(50,100);
		JLabel l1=new JLabel();//1
		JTextField t1=t1=new JTextField();
		JRadioButton r1=new JRadioButton("A) Male");    
		JRadioButton r2=new JRadioButton("B) Female");
		JCheckBox c1 = new JCheckBox("Java", true);  
		JCheckBox c2 = new JCheckBox("C++");  
		  JTextArea area=new JTextArea("Welcome");  
		f.add(l1);	
		f.add(t1);
		f.add(r1);	
		f.add(r2);
		f.add(c1);	
		f.add(c2);
		f.add(area);	
		
	
		
	}
	
}
