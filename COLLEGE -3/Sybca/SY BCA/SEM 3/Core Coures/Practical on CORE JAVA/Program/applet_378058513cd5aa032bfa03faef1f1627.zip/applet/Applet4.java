//show status
/*
<applet code="Applet4" width=400 height=400>
</applet>
*/

import java.applet.Applet;
import java.awt.Graphics;

public class Applet4 extends Applet {
   
    public void paint(Graphics g)
    {
        g.drawString("Applet started.", 100, 100);
        showStatus("This is shown in the status window.");
    }
}