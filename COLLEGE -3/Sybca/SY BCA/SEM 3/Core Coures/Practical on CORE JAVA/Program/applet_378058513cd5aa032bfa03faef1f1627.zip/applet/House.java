import java.awt.*;
import java.applet.Applet;
public class House extends Applet{
public void paint(Graphics g){

g.drawLine(100, 10, 80, 20);
g.drawLine(80, 20, 120, 20);
g.drawLine(120, 20, 100, 10);
g.drawLine(90, 20, 90, 50);
g.drawLine(110, 20, 110,50);
g.drawLine(90, 50, 110, 50);
}
}

     /* <applet code = "House.class" height = 200 width =200>  
       </applet> */
