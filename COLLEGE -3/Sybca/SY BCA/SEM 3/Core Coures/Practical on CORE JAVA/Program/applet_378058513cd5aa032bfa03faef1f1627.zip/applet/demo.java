import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class demo extends JFrame implements ActionListener
{
	JTextField t1,t2,t3,t4;
	JButton b1;
	demo(String s)
	{
	super(s);
	setVisible(true);	
	setSize(250,200);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;	
	setLayout(new FlowLayout(FlowLayout.LEFT));
	Font f=new Font("Arial",Font.BOLD, 15);
	t1=new JTextField();
	t1.setColumns(23);
	t2=new JTextField(20);
	t3=new JTextField("ABCD");
	t3.setEditable(false);
	t4=new JTextField("ENTER YOUR NAME",20);
	b1=new JButton("CLICK ME");
	b1.addActionListener(this);
	t4.setFont(f);
	add(t1);
	add(t2);
	add(t3);
	add(t4);
	add(b1);
	
	}	
	public void actionPerformed(ActionEvent e)
	{
		t1.setText(t4.getSelectedText());
		
	}
	public static void main(String args[])
	{
		new demo("DEMO");
	
		
	}
}
