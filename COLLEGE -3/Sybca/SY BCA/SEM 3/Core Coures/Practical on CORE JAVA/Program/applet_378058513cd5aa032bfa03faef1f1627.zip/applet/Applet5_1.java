//rect and fill rect

/*
<applet code="Applet5_1" width=200 height=200>
</applet>
*/

import java.applet.Applet;
import java.awt.Graphics;

public class Applet5_1 extends Applet 
{
 
    public void paint(Graphics g) 
{
     
        g.drawRect(10, 10, 70, 70); //x,y,w,h
        g.fillRect(100, 10, 70, 70); 
        g.drawRoundRect(10, 100, 70, 70,15,15); //x,y,w,h,arcw,arch
        g.fillRoundRect(100, 100, 70, 70,15,50); //x,y,w,h,arcw,arch
    }
}