/*
<applet code="SetForegroundColorExample" width=200 height=200>
</applet>
*/
 
 
import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
 
public class SetForegroundColorExample extends Applet{
 
        public void paint(Graphics g){
                /*
                 * Set foreground color of an applet using
                 * void setForeground(Color c) method.
                 */
               
                setForeground(Color.red);
                g.drawString("Foreground color set to red", 50, 50);
        }
}