/*
<applet code="Applet5_2" width=400 height=400>
</applet>
*/
 


    import java.applet.Applet;  
    import java.awt.*;  
      
    public class Applet5_2 extends Applet{  
      
    public void paint(Graphics g){  
    g.setColor(Color.red);  
    g.drawOval(70,200,30,30); //x,y,w,h  
      
    g.setColor(Color.pink);  
    g.fillOval(170,200,30,60); //x,y,w,h  
    g.drawArc(90,150,30,30,0,180);  //x,y,w,h,sA,arcA
    g.fillArc(270,150,30,30,0,180);  //x,y,w,h,sA,arcA
      
    }  
    }  
