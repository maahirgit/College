//line, rectage, set color

/*
<applet code="Applet5" width=200 height=200>
</applet>
*/
 


    import java.applet.Applet;  
    import java.awt.*;  
      
    public class Applet5 extends Applet{  
      
    public void paint(Graphics g){  
     
    g.drawString("Welcome",50, 50);  //string, x, y
    g.setColor(Color.red);  
    g.drawLine(20,20,20,300);  //x1, y1, x2,y2
    g.drawRect(70,100,30,50);  //x,y,w,h (70,100)
    g.setColor(Color.blue);  
    g.fillRect(70,180,30,30);  //x,y,w,h
     
      
    }  
    }  