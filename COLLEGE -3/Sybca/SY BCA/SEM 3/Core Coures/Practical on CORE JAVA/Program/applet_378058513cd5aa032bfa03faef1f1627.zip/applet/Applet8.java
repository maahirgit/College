    /*
<applet code="Applet8" width=200 height=200>
</applet>
*/

import java.awt.*;
import java.applet.*;
public class Applet8  extends Applet
{
    public void paint(Graphics g)
    {
        g.drawOval(40, 40, 120, 150); //face border
        g.drawOval(57, 75, 30, 20); //eye
        g.drawOval(110, 75, 30, 20); //eye
        g.fillOval(68, 81, 10, 10); //eye ball
        g.fillOval(121, 81, 10, 10); //eye ball
        g.drawOval(85, 100, 30, 30); //nose
        g.fillArc(60, 125, 80, 40, 180, 180); //mouth
        g.drawOval(25, 92, 15, 30); //eye
        g.drawOval(160, 92, 15, 30); //eye
    }

}
