//background and foreground color


/*
<applet code="Applet3" width=200 height=200>
</applet>
*/
 
import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
 
public class Applet3 extends Applet
{
 
        public void paint(Graphics g)
	{
                /*
                 * Set background color of an applet using
                 * void setBackground(Color c) method.
                 */
               
               setBackground(Color.red);
		
		g.setColor(Color.yellow);
		g.drawString("Foreground color set to yellow", 50, 50);
		g.setColor(Color.blue);
		g.drawString("Foreground color set to blue", 50, 150);
        }
}



