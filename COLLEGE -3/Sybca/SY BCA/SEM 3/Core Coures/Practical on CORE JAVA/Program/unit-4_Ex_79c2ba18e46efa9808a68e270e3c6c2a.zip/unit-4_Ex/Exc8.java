//throws keyword

  import java.io.IOException;  
    class Exc8
    {  
	
      void p() throws IOException
	{  
			
			throw new IOException("device error");//checked exception  
		      
		    
		    
      }  
      
      public static void main(String args[])
      {  
		try
		 {  
			Exc8 obj=new Exc8();  
			obj.p(); 
		}
		 catch(Exception e)
		    {
			    System.out.println("exception handled");
		    }  
	System.out.println("normal flow...");  
      }  
    }  
