    //throw example
    
    public class Exc7
    {  
       static void validate(int age)
	    {  
		     try
		 {
		if(age<18)  
			throw new Exception();  
		else  
			System.out.println("welcome to vote");  
		 }
		 catch(Exception e)
		{
			
			System.out.println("Not eligible...");  
		} 
		
	 }  
       
	 public static void main(String args[])
	 {  
		validate(3);  
		System.out.println("rest of the code...");  
      }  
    }  