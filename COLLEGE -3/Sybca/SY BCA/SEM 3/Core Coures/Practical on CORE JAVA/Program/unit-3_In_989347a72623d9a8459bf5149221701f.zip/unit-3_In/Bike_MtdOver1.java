    
    //Method Overriding 1
    
    
    class Vehicle
    {  
      void run()
	    {
		    System.out.println("Vehicle is running");
		}  
    }  
    
    class Bike_MtdOver1 extends Vehicle
    {  
        
      public static void main(String args[])
	{  
      Bike_MtdOver1 obj = new Bike_MtdOver1();  
      obj.run();  
      }  
    }  