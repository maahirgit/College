class A
{
	int a,b;
	A(int e,int f)
	{
		a = e;
		b = f;
	}
}


class B extends A
{
	int c,d;
	B(int e,int f,int g, int h)
	{
		super(e,f);
		c = g;
		d = h;
	}
	
	void display()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}

class Inheritance15
{
	public static void main(String args[])
	{
	B b1 = new B(1,2,3,4);
	b1.display();
	}
	
}