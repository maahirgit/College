//final method

   class Bike
   {  
      final void run()
	   {
		   System.out.println("running");
	   }  
    }  
         
    class Inheritance13 extends Bike
    {  
       void run()
	    {
		  //  super.run();
		    System.out.println("running safely with 100kmph");
	    }  
         
       public static void main(String args[])
	{  
		Inheritance13 honda= new Inheritance13();  
		honda.run();  
       }  
    }  
