    //interfaces
    
    interface printable
    {  
	void print();  
    }  
    
    class Inheritance21 implements printable
    {  
	 void print()
		{
			System.out.println("Hello");
		}  
      
    public static void main(String args[])
    {  
	Inheritance21 obj = new Inheritance21();  
	obj.print();  
     }  
    }  