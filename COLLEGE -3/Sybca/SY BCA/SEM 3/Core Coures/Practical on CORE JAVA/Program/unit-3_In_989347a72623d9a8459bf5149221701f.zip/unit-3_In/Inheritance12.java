//final variable


class Inheritance12
{  
	final int speedlimit=90;//final variable  
	void run()
	{  
		//speedlimit=400;  
		int x=10+speedlinmit;
		System.out.println(speedlimit);
	}
	
	public static void main(String args[])
	{  
		Inheritance12 obj=new  Inheritance12();  
		obj.run();  
	}  
}
