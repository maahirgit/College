    //abstract class with abstract method
    
    abstract class Bike
    {  
      abstract void run();
	    void get(){}
    }
    
    class Honda4 extends Bike
    {  
    
	    void run()
	    {
		    System.out.println("running safely..");
	    }
    }
    
    class Inheritance16
    {
	public static void main(String args[])
	    {  
		   // Bike obj = new Bike();
			//Bike obj = new Honda4();  
		    Honda4 h = new Honda4();
			h.run();  
		}  
    }  