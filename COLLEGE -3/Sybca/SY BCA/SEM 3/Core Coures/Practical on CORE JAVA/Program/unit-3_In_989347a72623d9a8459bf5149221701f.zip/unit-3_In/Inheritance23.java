    //Multiple Inheritance
    
    interface Printable
    {  
	void print();  
    }  
    
    interface Showable
    {  
	void show();  
    }  
    
    class Inheritance23 implements Printable,Showable
    {  
	public void print()
		{
			System.out.println("Hello");
		}
		
	public void show()
		{
			System.out.println("Welcome");
		}  
      
	public static void main(String args[])
		{  
			Inheritance23 obj = new Inheritance23();  
			obj.print();  
			obj.show();  
		}  
    }  