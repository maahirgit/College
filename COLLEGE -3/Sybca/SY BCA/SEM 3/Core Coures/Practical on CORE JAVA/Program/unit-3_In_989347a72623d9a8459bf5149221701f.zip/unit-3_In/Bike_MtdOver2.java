 //Method Overriding 2
	
	class Vehicle
    {  
    void run()
	    {
		    System.out.println("Vehicle is running");
	}  
    }  
    
    
    class Bike_MtdOver2 extends Vehicle
    {  
    void run()
	    {
		    System.out.println("Bike is running safely");
	    }  
      
    public static void main(String args[])
    {  
    Bike_MtdOver2 obj = new Bike_MtdOver2();  
    obj.run();  
    }  
    }