//final class

  final class Bike
  {
	  int r;
  }
	  
      
    class Inheritance14
   {  
	void run()
	   {
		   System.out.println("running safely with 100kmph");
	   }  
        
      public static void main(String args[])
     {  
	Inheritance14 honda= new Inheritance14();  
	honda.run();  
	Bike b = new Bike();
	b.r = 100;
	System.out.println(b.r);
      }  
    }  