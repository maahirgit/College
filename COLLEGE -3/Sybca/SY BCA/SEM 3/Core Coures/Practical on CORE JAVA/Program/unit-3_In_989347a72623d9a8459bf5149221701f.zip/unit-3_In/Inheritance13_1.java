//final method

   class Bike
   {  
      final void run()
	   {
		   System.out.println("running");
	   }  
    }  
         
    class Inheritance13_1 extends Bike
    {  
       void run1()
	    {
//		    super.run();
		    run();
		    System.out.println("running safely with 100kmph");
	    }  
         
       public static void main(String args[])
	{  
		Inheritance13_1 honda= new Inheritance13_1();  
		honda.run1();  
       }  
    }  