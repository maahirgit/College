    //abstract class and interface
    
    interface A
    {  
	void a();  
	void b();  
	void c();  
	void d();  
    }  
      
    abstract class B implements A
    {  
	public void c()
		{
			System.out.println("I am C");
		}  
	public void temp()
		{
			System.out.println("I am in temp");
		}
    }  
      
    class M extends B
    {  
	public void a()
		{
			System.out.println("I am a");
		} 
		
	public void b()
		{
			System.out.println("I am b");
		}
		
	public void d()
		{
			System.out.println("I am d");
		}  
    }  
      
    class Inheritance20
    {  
	public static void main(String args[])
		{  
			A a=new M();  
			a.a();  
			a.b();  
			a.c();  
			a.d(); 
			M m =new M();
			m.temp();			
		}
	}  