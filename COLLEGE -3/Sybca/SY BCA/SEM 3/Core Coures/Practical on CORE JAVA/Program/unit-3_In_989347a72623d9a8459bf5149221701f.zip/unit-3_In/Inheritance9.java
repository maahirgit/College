//super is used to invoke parent class constructor.

   class Animal
   {  int a;
	Animal()
	   {
		   a=10;
		   System.out.println("animal is created");
	   }  
    }  
    
    class Dog extends Animal
    {  
	int a;
	Dog()
	    {  
		  //  super();
		    a=100;
		
			
			System.out.println("dog is created");  
	   }  
    }  
    
    class Inheritance9
    {  
	public static void main(String args[])
	    {  
			Dog d=new Dog();  
	    }
   }  
