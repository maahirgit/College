   
    interface Printable
    {  
	void print();  
    }  
    
    interface Showable
    {  
	void print();  
    }  
      
    class Inheritance24 implements Printable, Showable
    {  
	public void print()
		{
			System.out.println("Hello");
		}
		
	public static void main(String args[])
		{  
			//Inheritance24 obj = new Inheritance24();  
			Showable obj = new Inheritance24();
			obj.print();  	
		}  
    }  