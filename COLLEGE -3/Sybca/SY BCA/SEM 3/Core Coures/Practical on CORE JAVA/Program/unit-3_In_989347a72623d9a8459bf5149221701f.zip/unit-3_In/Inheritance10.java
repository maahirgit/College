//super is created implicity by the compiler

   class Animal
   {  
	Animal()
	   {
		   System.out.println("animal is created");
	   }  
    }  
    
    class Dog extends Animal
    {  
	Dog()
	    {  
	
		System.out.println("dog is created");  
	   }  
    }  
    
    class Inheritance10
    {  
	public static void main(String args[])
	    {  
			Dog d=new Dog();  
	    }
   }  
