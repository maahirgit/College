//package example using fully qualified name

package pack;  
public class Package6
	{  
		public void msg()
			{
				System.out.println("Hello");
			}  
	}  