//package example

package pack2;  
public class Test
	{  
		public void msg()
			{
				System.out.println("Hello");
			}  
	}  
