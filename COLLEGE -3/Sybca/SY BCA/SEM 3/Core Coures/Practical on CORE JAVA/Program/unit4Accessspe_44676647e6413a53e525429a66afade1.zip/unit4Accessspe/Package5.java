//importing a package using class name

package mypack;  
import pack.Package4;  
  
class Package5
{  
  public static void main(String args[])
	  {  
		Package4 obj = new Package4();  
		obj.msg();  
	
		  }  
}  