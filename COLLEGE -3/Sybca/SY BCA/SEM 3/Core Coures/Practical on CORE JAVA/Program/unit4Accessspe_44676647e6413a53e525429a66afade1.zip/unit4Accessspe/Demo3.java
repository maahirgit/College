//importing a package

package pack3;  
import pack2.*;  
  
class Demo3
{  
  public static void main(String args[])
	  {  
		Test obj = new Test();  
		obj.msg();  
	
		  }  
}  
