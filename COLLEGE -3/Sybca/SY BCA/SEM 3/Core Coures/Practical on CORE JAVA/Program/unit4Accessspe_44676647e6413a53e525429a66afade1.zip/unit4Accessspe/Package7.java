//importing a package using fully qualified name

package mypack;  
//import pack;  
  
class Package7
{  
  public static void main(String args[])
	  {  
		pack.Package6 obj = new pack.Package6();  
		obj.msg();  
	
		  }  
}  