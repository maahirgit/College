//package1

		 

package p1;

public class Demo1
{
	public static void main(String args[])
			{  
				System.out.println("Welcome to package");  
			}  


}

