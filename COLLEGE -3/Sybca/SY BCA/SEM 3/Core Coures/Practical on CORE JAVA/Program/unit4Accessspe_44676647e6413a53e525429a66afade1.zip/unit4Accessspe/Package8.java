    //subpackage
    
    package abc.java.core;
    
    class Package8
    {  
      public static void main(String args[])
	    {  
		System.out.println("Hello subpackage");  
	    }  
    }  
