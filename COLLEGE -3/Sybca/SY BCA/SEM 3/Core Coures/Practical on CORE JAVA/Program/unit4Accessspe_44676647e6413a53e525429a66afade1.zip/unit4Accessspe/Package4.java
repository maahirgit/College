//package example

package pack;  
public class Package4
	{  
		public void msg()
			{
				System.out.println("Hello");
			}  
	}  