//default acccess specifier
//using package

package pack1;  
import pack.*;  

class Access4 extends Access3
{  
  public static void main(String args[])
	  {  
		Access4 obj = new Access4();
		obj.msg();//
	}  
}  
