//java.lang.Object class



public class Class2
{
	public String toString()
	{
		
		return "Demo of Object class";
	}
	
   public static void main(String[] args) 
	{
		Class2 z = new Class2();
		Class2 z1=new Class2();
		System.out.println(z);
		System.out.println(z1);
		
	}
}	
	
	
