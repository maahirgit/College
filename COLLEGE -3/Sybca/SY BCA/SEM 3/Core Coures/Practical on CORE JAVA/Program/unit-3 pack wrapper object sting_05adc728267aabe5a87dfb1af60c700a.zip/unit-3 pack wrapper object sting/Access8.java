//public acccess specifier
//using package

package mypack;  
import pack.*;  

class Access8 extends Access7
{  
  public static void main(String args[])
	  {  
		Access8 obj = new Access8();
		obj.msg();  
	}  
}  