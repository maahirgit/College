//converting back from STring object to primitive

public class Class5 
	{ 

   public static void main(String args[]) 
	   {
		int x =Integer.parseInt("9");
		double c = Double.parseDouble("5");
		int b = Integer.parseInt("A",16); //A in hexa - decimal 10

		System.out.println(x);
		System.out.println(c);
		System.out.println(b);
   }
}