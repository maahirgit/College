//converting wrapper classes to primitives

public class Class10
{
	public static void main(String[] args)
	{
	

		Integer I = new Integer(15);    //Integer Object
		int i = I.intValue();           //Unwrapping Integer object to int data
		System.out.println(i);
		Character C = new Character('C');    //Character Object
		char c = C.charValue();              //Unwrapping Character object to char data
		System.out.println(c);
	}
}
