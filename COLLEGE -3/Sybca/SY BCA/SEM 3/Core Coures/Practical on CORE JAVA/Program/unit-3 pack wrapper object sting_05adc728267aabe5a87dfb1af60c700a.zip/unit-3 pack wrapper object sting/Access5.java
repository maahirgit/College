//protected acccess specifier
//using package

package pack;  
public class Access5
{  
	protected int x=10;
	protected void msg()
	{
		System.out.println("Hello x is:"+ x);
	}  
}  