//private access modifier

   class A
   {  
	private int data=40;  
	private void msg()
	   {
		   System.out.println("data is"+data +"Hello java");
	   }  
	void work()
	{
	this.msg();
	}
    }  
      
    public class Access1
    {  
	    
	public static void main(String args[])
	    {  
		A obj=new A();  
		System.out.println(obj.data);//Compile Time Error  
		obj.work();//Compile Time Error  
	    }  
    }  
