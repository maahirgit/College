//default acccess specifier
//using package

package pack;  
public class Access3
{  
 	protected void msg()
	{
		System.out.println("Hello");
	}  
}  
