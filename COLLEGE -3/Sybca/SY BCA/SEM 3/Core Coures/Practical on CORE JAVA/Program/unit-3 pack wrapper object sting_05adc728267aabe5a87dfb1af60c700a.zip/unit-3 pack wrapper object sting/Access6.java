//protected acccess specifier
//using package

package mypack;  
import pack.Access5;  

class Access6 extends Access5
{  
  public static void main(String args[])
	  {  
		Access6 obj = new Access6();
		obj.msg();  
	}  
}  