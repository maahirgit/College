//converting primitive types to wrapper objects with the help of constructor

public class Class9
{
	public static void main(String[] args)
	{
		
		Integer I1 = new Integer(30);     //Constructor which takes int value as an argument
		Integer I2 = new Integer("30");   //Constructor which takes String as an argument

		Character C1 = new Character('D');      //Constructor which takes char value as an argument
		Character C2 = new Character('a');    //Compile time error : String abc can not be converted to character
		System.out.println(C2);
	}
}
