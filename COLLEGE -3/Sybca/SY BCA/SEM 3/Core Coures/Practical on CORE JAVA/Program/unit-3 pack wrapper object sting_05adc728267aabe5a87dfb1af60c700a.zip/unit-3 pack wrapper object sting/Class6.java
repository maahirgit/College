//Autoboxing

public class Class6
{
	public static void main(String[] args)
	{
		byte b = 10;    //Primitive byte data
		Byte B = 10;    //Auto-Boxing of byte data

		//Byte B=new Byte(10)

		short s = 15;     //Primitive short data
		Short S = s;     //Auto-Boxing of short data

		int i = 20;       //Primitive int Data
		Integer I = i;    //Auto-Boxing of int data

		long l = 25;    //Primitive long data
		Long L = l;     //Auto-Boxing of long data

		float f = 12;     //Primitive float data
		Float F = f;     //Auto-Boxing of float data

		double d = 18.58;     //Primitive double data
		Double D = d;        //Auto-Boxing of double data

		boolean bln = true;    //Primitive boolean data
		Boolean BLN = bln;     //Auto-Boxing of boolean data

		char c = 'C';          //Primitive char data
		Character C = c;     //Auto-Boxing of char data
	}
}
