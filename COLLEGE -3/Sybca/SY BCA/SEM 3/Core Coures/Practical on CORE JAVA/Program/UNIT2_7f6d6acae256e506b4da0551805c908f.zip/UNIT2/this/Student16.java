    //with this pointer
    
    class Student16
    {  
        int id;  
        String name;  
          
        Student16(int id,String name)
	{  
		this.id = id;  
		this.name = name;  
        }  
        void display()
	{
		System.out.println(id+" "+name);
	}  
      
        public static void main(String args[])
	{  
        Student16 s1 = new Student16(111,"Karan");  
        Student16 s2 = new Student16(321,"Aryan");  
        s1.display();  
        s2.display();  
        }  
    }  