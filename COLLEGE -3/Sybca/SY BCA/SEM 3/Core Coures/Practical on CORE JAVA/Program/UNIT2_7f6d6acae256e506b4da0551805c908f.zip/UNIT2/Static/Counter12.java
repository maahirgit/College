    //static variable 
    
    
    class Counter12
    {  
	static int count=0;//will get memory when instance is created  
      
	Counter12()
	{  
		count++;  
		System.out.println(count);  
    }  
      
    public static void main(String args[])
	{  
      
		Counter12 c1=new Counter12();  
		Counter12 c2=new Counter12();  
		Counter12 c3=new Counter12();  
      
     }  
    }  
