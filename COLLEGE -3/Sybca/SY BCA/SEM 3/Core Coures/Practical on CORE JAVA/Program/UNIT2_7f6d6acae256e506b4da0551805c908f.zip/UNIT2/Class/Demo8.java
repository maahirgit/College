
//method overloading 1
    
    class Demo8
    {
	
	void sum(int a,int b)
	{
		System.out.println(a+b);
	}  
      
	void sum(int a,int b,int c)
	{
		System.out.println(a+b+c);
	}  
      
      public static void main(String args[])
	{  
	Demo8 obj=new Demo8();  
	obj.sum(10,10,10);  
	obj.sum(20,20);  
      
      }  
    }  
