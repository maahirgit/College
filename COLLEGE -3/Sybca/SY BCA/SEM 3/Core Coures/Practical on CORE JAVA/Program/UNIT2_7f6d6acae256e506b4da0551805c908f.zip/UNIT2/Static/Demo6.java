
class student
{
	int rollno; //instance varibale
	static int var=0; //static variable  //class varibale
	static String colgname;
	public static void method()
	{
	//System.out.println("\n rollno is:"+ rollno); 
	System.out.println("\n var is:"+ var); 
	System.out.println("\n colgname is:"+ colgname); 
	}
	public void method2()
	{
	System.out.println("\n rollno is:"+ rollno); 
	System.out.println("\n var is:"+ var); 
	System.out.println("\n colgname is:"+ colgname); 
	}
}
class Demo6
{
	
	public static void main(String args[])
	{
	student s1=new student();
	s1.method2();
	student.method();
	}
}
