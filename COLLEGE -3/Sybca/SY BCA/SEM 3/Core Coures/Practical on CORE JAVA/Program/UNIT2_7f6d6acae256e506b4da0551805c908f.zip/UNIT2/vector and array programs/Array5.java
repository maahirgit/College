//for each

class Array5
{  
 public static void main(String args[])
{  
   int arr[]={12,13,14,44};  
  
   for(int i:arr)
  {  
     System.out.println(i);  
   }  
  
 }   
}  