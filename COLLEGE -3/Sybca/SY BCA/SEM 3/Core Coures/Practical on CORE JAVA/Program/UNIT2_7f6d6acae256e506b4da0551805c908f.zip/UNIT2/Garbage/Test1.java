public class Test1
{ 
	public void finalize()
	{
		System.out.println("object is garbage collected");
	//	    System.out.println(t1);
        
		
	}  
    public static void main(String[] args) throws InterruptedException 
    { 
	 
        Test1 t1 = new Test1(); 
        Test1 t2 = new Test1(); 
	System.out.println(t1);
        // Nullifying the reference variable 
        t1 = null; 
        t2 = null;   
    System.out.println(t1);
        System.gc(); 
          
         System.out.println(t1);
        
      
    } 
}
