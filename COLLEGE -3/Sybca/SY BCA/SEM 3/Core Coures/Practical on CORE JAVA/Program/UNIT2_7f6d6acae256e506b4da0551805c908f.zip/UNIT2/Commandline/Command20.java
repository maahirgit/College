class Command20
{
  public static void main(String[] args) 
{
	int length = args.length;
	System.out.println("lenght is:"+length);
	int a[] = new int[length];
	
	for(int i=0;i<length;i++)
   { 
      // convert into integer type
	a[i] = Integer.parseInt(args[i]);
	System.out.println("Argument in integer form: " + a[i]);
    }
    

  }
}
