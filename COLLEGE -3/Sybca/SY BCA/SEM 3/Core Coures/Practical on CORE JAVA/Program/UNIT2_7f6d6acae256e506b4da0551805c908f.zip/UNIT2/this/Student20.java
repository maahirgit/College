
// Java code for using this() to  
// invoke current class constructor 
class Student
{ 
    int a; 
    int b; 
  
   	void getData()
	{
	//Scanner
	this.putData();
	}
	void putData()
	{

	}
    public static void main(String[] args) 
    { 
        Student object = new Student); 
	 object.getData();
    } 
} 


