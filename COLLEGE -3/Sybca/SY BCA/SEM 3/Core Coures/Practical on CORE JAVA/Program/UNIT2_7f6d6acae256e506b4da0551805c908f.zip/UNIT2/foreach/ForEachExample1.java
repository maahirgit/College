class ForEachExample1
{  
  public static void main(String args[])
	  {  
		//declaring an array  
		int arr[]={12,13,14,15};  //array
		
		//for(int i=0;i<arr.length;i++)	
	//	{
	//	arr[i]=arr[i]*10;
	//	System.out.println(arr[i]);  
	//	}

		//traversing the array with for-each loop  
		
		for(int temp:arr)
		{
		temp=temp*10;
		System.out.println(temp);  
		}

		for(int temp:arr)
		{
		
		System.out.println(temp);  
		}
		
}		


		
   
}  
