
// Java code for using this() to  
// invoke current class constructor 
class Student18 
{ 
    int a; 
    int b; 
  
    //Default constructor 
    Student18() 
    {   
        this(10, 20); 
        System.out.println("Inside  default constructor \n"); 
    } 
      
    //Parameterized constructor 
    Student18(int a, int b) 
    { 
        this.a = a; 
        this.b = b; 
        System.out.println("Inside parameterized constructor"); 
    } 
  
    public static void main(String[] args) 
    { 
        Student18 object = new Student18(); 
	System.out.println(object.a);
	System.out.println(object.b);
    } 
} 


