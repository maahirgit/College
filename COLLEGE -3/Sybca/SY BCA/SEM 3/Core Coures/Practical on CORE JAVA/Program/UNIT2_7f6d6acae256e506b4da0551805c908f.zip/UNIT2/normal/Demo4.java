
class student
{
	int rollno; //instance varibale
	static int count=0; //static variable  //class varibale
	public student()
	{
	count++;
	}
	
}
class Demo20
{
	
	public static void main(String args[])
	{
	student s1=new student();
	student s2=new student();
	student s3=new student();
	student s4=new student();
	System.out.println("\n count is:"+ student.count); 
	}
}
