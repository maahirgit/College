public class Test 
{ 
    public static void main(String[] args) 
    { 
        Test t1 = new Test(); 
        Test t2 = new Test(); 
          
        // Nullifying the reference variable 
        t1 = null; 
          
        // requesting JVM for running Garbage Collector 
        System.gc(); 
          
        // Nullifying the reference variable 
        t2 = null; 
          
        // requesting JVM for running Garbage Collector 
        Runtime.getRuntime().gc(); 
      
    } 
}