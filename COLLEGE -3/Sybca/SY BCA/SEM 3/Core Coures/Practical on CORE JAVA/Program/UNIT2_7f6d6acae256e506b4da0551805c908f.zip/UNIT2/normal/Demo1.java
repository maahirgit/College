
//normal methods in java
class Demo1
{
	public static void add(int x,int y)
	{
	int c=x+y;
	System.out.println("addition is:"+c);
	}
	public static void main(String args[])
	{
	add(11,12);

	}

}
