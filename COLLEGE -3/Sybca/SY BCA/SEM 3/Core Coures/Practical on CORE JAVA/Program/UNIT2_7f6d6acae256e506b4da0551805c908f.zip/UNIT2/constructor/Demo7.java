//default constructor

class Demo7
{  
    Demo7()
   {
	   System.out.println("Bike is created");
   }  
   
   public static void main(String args[])
   {  
   Demo7 b=new Demo7();  
    }  
    }  
