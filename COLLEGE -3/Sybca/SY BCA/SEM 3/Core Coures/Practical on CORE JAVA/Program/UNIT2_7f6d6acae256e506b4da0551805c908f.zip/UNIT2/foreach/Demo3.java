class Demo3
{
 public static void main(String[] args) 
{
          First:
         for (int i=0;i<=5;i++)
	{
		for(int j=0;j<i;j++)	
		{
			if(i==2)
			{	
			break First;
			}
			System.out.print(i);
		}
	
	System.out.println("\n");
	}

}

}
