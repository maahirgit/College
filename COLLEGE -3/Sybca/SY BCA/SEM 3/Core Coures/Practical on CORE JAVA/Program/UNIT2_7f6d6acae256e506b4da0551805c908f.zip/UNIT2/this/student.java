class student
{

	int rollno;
	String name;
	float marks;

	public student(int rollno, String name, float marks)
	{
	this.rollno=rollno;
	this.name=name;
	this.marks=marks;

	}
	public void display()
	{
	System.out.println(rollno);
	System.out.println(name);
	System.out.println(marks);
	}
	public static void main(String args[])
	{
	student s1=new student(11,"vidhi",23);
	s1.display();
	student s2=new student(12,"ivana",3);
	s2.display();
	}

}



