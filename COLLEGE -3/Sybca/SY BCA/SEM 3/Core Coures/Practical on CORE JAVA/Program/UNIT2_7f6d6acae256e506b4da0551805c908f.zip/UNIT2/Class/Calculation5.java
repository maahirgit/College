    //method overloading2
    
    class Calculation5
    {  
	void sum(int a,int b)
	{
		System.out.println(a+b);
	}  
	
	void sum(double a,double b)
	{
		System.out.println(a+b);
	}  
      
      public static void main(String args[])
	{  
      Calculation5 obj=new Calculation5();  
      obj.sum(10.5F,10.5F);  
      obj.sum(20,20);  
      
      }  
    }  
