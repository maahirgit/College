//passing array to method

class Array7
{  
 public static void main(String args[])
{  
   int arr[]={12,13,14,44};  
  
  printArray(arr);
  
 }   
 
 public static void printArray(int[] array) 
	 {
   for (int i = 0; i < array.length; i++) {
      System.out.println(array[i] );
   }
}
}  