    //without this pointer
    //implicit pointer
    class Student15
    {  
        int id;  
        String name;  
          
        Student15(int id,String name)
	{  
		id = id;  
		name = name;  
        }  
        void display()
	{
		System.out.println(this);
		System.out.println(id+" "+name);
	}  
      
        public static void main(String args[])
	{  
        Student15 s1 = new Student15(111,"Karan");  
        Student15 s2 = new Student15(321,"Aryan");  
        s1.display();  
        s2.display();  
        }  
    }  
