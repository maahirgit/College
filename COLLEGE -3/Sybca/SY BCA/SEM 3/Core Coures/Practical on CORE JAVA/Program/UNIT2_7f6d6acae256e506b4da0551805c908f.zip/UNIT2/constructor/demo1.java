//constructor name same as classs name
//public
//no return type
//can have arguments //parameterized
//no need to call
//automaticaally when u create object


class Circle
{
 	final float PI =3.14F;
 	float radius;
	public Circle()
	{
	radius=10;
	}
 	public void display()
 	{
	System.out.println("PI is"+ PI);
	System.out.println("radius is:" + radius);
 	}
  
}

class demo1
{
	public static void main(String args[])
	{
	Circle c1=new Circle();
	c1.display();
	Circle c2=new Circle();
	c2.display();
	}
	
}
