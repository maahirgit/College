class Demo
{
	public static void main(String args[])
	{
	int len=args.length;
	for(int i=0;i<len;i++)
	{
	System.out.println(args[i]);
	
	}
	}
}
