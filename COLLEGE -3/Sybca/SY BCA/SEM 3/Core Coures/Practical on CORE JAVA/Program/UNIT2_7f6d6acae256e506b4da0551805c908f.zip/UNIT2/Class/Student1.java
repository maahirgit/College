class Student1
{  
	
	 int id;
	 String name;  
	void display()
	{
		System.out.println(id); 
		System.out.println(name);  
	}
	 public static void main(String args[])
	{  
		
		Student1 s1=new Student1();
		s1.id = 10;
		s1.name = "abcd";
		s1.display();
		
	}  
}  
