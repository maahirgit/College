//string to int

public class Demo7
{  
	public static void main(String args[])
	{  
	System.out.println(args[0]);
	System.out.println(args[1]);
	int n1,n2;
	n1=Integer.parseInt(args[0]);
	n2=Integer.parseInt(args[1]);
	System.out.println("add is:"+ (n1+n2));		
	}
}  
