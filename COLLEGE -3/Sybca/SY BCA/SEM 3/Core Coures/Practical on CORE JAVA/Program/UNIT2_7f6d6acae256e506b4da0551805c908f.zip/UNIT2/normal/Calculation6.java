    //method overloading 
    
    class Calculation6
    {
	    
	public static void sum(int a,char b)
	{
		System.out.println(a + " " + b);
	}  
      
	public static void sum(char a,int b)
	{
		System.out.println(a + " " + b);
	}  
      
      public static void main(String args[])
	{  
	
	sum(10, 'a');  
	sum('b',20);  
      
      }  
    }  
