
class student
{
	int rollno; //instance varibale
	static int var=0; //static variable  //class varibale
	static String colgname;
	public void static method()
	{
	System.out.println("\n rollno is:"+ rollno); 
	}
	
}
class Demo5
{
	
	public static void main(String args[])
	{
	student s1=new student();
	System.out.println("\n count is:"+ student.var); 
	student.var=13; //classname.variablename
	student.colgname="GLS";
	System.out.println("\n count is:"+ student.colgname); 
	}
}
