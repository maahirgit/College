
class Triangle 
{
	
    int x, y;  //by default access specifier is default in java
    void printArea()
    {
        System.out.println("Area of triangle is: " + x * y / 2);
    }
}
  
class Demo 
{
    public static void main(String args[])
    {
        // Object creation
        Triangle t = new Triangle();
        t.x = 10; //we can access default variables outside class
        t.y = 13;
        t.printArea();
    }
}
