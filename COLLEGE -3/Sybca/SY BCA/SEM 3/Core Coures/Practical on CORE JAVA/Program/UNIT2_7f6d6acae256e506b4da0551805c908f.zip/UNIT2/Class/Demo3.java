class student
{
	int rollno; //instatnce variables
	int m1,m2;
	public void getdata() //member function
	{
	rollno=1;
	m1=45;
	m2=50;
	}
	public void putdata()
	{
	System.out.println("\n rollno is:" +rollno);
	System.out.println("\n m1 is:" +m1);
	System.out.println("\n m2 is:" +m2);
	}

}

class Demo3
{
	public static void main(String args[])
	{
	student s1=new student();
	s1.getdata();
	s1.putdata();
	}

}
