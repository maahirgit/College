class Circle
{
 	final float PI =3.14F;
 	float radius;
	public Circle() //default explicit constructor
	{
	radius=10;
	}
	public Circle(float r) //paramiterized constructor
	{
	radius=r;
	}
 	public void display()
 	{
	System.out.println("PI is"+ PI);
	System.out.println("radius is:" + radius);
 	}
  
}

class demo2
{
	public static void main(String args[])
	{
	Circle c1=new Circle(); //default
	c1.display();
	Circle c2=new Circle(12.13F); //parametrized
	c2.display();
	}
	
}
