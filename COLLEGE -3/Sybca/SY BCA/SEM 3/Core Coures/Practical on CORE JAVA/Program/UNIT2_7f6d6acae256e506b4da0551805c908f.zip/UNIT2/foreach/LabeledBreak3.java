class LabeledBreak3
    {
       public static void main(String[] args) 
	{
          
          first:
	 for( int i = 1; i < 5; i++)  //1 to 4
	{
             second:
             for(int j = 1; j < 3; j ++ )  //1 to 2
		{
			third:
			for(int k=1;k<3;k++) //1 to 2
			{
				System.out.println("i = " + i + "; j = " +j + "; k = " +k);
                 
				if ( i == 2)
					break second;
			}
             }
          }
       }
    }