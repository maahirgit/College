//returning array from method

class Array8
{  
 public static void main(String args[])
{  
   int arr[]={12,13,14,44};  
  
  int arr1[]  = printArray(arr);
      for (int i = 0; i < arr1.length; i++)
   {
	System.out.println(arr1[i]);
   }
 }   
 
 public static int[] printArray(int[] array) 
	 {
   for (int i = 0; i < array.length; i++) {
      array[i] = array[i] + 10;
   }
   return array;
}
}  