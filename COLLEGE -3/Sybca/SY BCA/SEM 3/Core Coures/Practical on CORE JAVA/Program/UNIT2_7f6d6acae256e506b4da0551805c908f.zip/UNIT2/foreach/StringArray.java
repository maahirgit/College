import java.util.Scanner;  
class StringArray
{

    public static void main(String[] args)
                 {
			Scanner in = new Scanner(System.in);
     
			System.out.print("how many students you want to enter?:");
			int totalStudents = in.nextInt();
     
			String[] studentNames = new String [totalStudents];
     
        
		for(int j = 0; j < studentNames.length;j++) 
		{
			System.out.print("enter student name:");
			studentNames[j] = in.next();
		}
     
		for (String element:studentNames)
		{   
			System.out.println(element);
		}
	}

}