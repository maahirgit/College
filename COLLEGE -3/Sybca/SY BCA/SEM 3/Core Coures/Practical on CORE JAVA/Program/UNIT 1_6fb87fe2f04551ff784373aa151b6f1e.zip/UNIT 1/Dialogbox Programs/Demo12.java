import javax.swing.JOptionPane;

class Demo12
{
	public static void main(String[] arg)
	{
		int a= 10;
		JOptionPane.showMessageDialog(null,a);
		JOptionPane.showMessageDialog(null,"a is:"+a,"TITLE",JOptionPane.WARNING_MESSAGE);
	}
}
