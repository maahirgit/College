class Demo5
{
	public static void main(String args[])
	{
	float f=12;//implicit casting
	Double d=12.45f;
	int x=(int)12.78f;//explicit casting
	System.out.println("\n x is:"+x);
	}

}

