//Scanner
import java.util.Scanner;
public class ScannerDemo2
{
    public static void main(String[] args)
    {
	System.out.println("Enter first no:");
        Scanner sc = new Scanner(System.in);
	int num1 = sc.nextInt();
  
       System.out.println("Enter second no:");
       	int num2 = sc.nextInt();
	
	int num3 = num1 + num2;
 
        System.out.println("Addition: "+ num3);

    }
}
