import javax.swing.JOptionPane;

class messagedialog1
{
	public static void main(String[] arg)
	{
		int a= 10;
		JOptionPane.showMessageDialog(null,"The value of a is" + a,
		"Value of A",JOptionPane.INFORMATION_MESSAGE);
		
		JOptionPane.showMessageDialog(null,"Hi SYBCA Div C","Hi",
		JOptionPane.QUESTION_MESSAGE);
	}
}
