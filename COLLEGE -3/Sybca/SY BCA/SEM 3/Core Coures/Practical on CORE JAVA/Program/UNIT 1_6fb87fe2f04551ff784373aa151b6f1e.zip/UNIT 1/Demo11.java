class Demo11
{
	public static void main(String args[])
	{
	int no1=2,no2=3,no3=9;
	System.out.println("\n max is:"+ Math.max(no1,no2));
	System.out.println("\n power is:"+ Math.pow(no1,no2));
	System.out.println("\n sqrt is:"+ Math.sqrt(no3));
	}

}

