import javax.swing.JOptionPane;

class Demo15
{
	public static void main(String[] arg)
	{
	int no1;
	no1 = Integer.parseInt(JOptionPane.showInputDialog(null,"ENter number:","NUMBER"));
	System.out.println("My number is " + (no1*no1));
		
	}
}
