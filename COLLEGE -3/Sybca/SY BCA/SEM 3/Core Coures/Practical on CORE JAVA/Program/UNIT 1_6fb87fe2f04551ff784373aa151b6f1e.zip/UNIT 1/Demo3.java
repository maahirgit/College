import java.util.Scanner;
class Demo3
{

	public static void main(String args[])
	{
	String name;
	int rollno;
	float m1,m2;
	String address;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter name");
	name=sc.nextLine();
	System.out.println("name is:" + name);
	System.out.println("Enter address");
	address=sc.nextLine();
	//sc.next();
	System.out.println("Address:" + address);
	System.out.println("Enter Rollno");
	rollno=sc.nextInt();
	System.out.println("Rollno is:" + rollno);
	System.out.println("Enter m1");
	m1=sc.nextFloat();
	System.out.println("m1 is:" + m1);
	
	}


}
