//basic data types in java
//total 8
// also termed as primitive or in-built data types
class Demo6
{
	public static void main(String args[])
	{
	int x=12; //4 byte
	short s=23; //2 byte 
	long l=345656; //8 byte
	float f=23.45; //4 byte
	double d=34.5767676; //8 byte 
	boolean b=1; //1 bit	
	byte by=10010101;  //1 byte
	char ch='a'; // 2 byte
	}

}
