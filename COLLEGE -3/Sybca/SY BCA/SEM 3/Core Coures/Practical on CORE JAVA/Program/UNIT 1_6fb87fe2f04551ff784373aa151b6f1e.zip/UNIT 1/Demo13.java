class student
{
	public void print()
	{
	int p,q;//local variables
	}

}
class Demo13
{
	public static void add()
	{
	int a,b;//local variables
	}
	public static void main(String args[])
	{

	int x,y;//local variables


	}

}
