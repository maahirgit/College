import javax.swing.JOptionPane;

class Demo16
{
	public static void main(String[] arg)
	{
	String name;
	name = JOptionPane.showInputDialog(null,"ENter name:","temp");
	System.out.println("name is " + (name));
		
	}
}
