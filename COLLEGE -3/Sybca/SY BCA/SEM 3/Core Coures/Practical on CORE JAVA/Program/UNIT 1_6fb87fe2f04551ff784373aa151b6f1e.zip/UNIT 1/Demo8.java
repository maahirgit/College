datatype  size
boolean   1 bit    boolean b=1; boolean b=true;
byte      1 byte    byte b1=10101000;
char      2 byte    char ch="A";
short     2 byte    short s=12;
int       4 byte    int s=123;
long      8 byte    long l=1234353454;
float     4 byte    float f=23.45556F;
double    8 byte    double d=34.57687799;
