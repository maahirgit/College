import javax.swing.JOptionPane;

class confirmdialog1
{
	public static void main(String[] arg)
	{
		int value;
		value=JOptionPane.showConfirmDialog(null,"Do you want to proceed?","Continue",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
		System.out.println(value);	
		if(value==0)
		{
			System.out.println("You have clicked on YES");
		}
		else if(value==1)
		{
			System.out.println("You have clicked on NO");
		}	
		else
		{
			System.out.println("You have clicked on CANCEL");
		}
	}
}