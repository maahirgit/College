//java.lang package
//no need to import this package
//Object, Class, Math, String, System, Wrapper Classes,
short x=12;   
size 2 byte

1 byte   ---> 8 bit
2- byte    ---->16 bit  


binary  0/1 total 2

binary lang base 2

2 raise to 16

65536

divide 2

0 to 32767 pos   -1 to -32768

short x=65536;
