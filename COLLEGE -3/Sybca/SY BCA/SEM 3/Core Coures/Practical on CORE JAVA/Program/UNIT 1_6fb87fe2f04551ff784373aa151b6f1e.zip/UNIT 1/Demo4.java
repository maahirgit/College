import java.util.Scanner;
class Demo4

{
	public static void main(String args[])
	{
	String name;
	int rollno;
	float marks;
	boolean ans;

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Rollno:");
	rollno=sc.nextInt();
	System.out.println("ROllno is:" + rollno);
	
	System.out.println("Enter marks:");
	marks=sc.nextFloat();
	System.out.println("marks is:" + marks);
	
	System.out.println("Enter ans:");
	ans=sc.nextBoolean();
	System.out.println("ans is:" + ans);
	System.out.println("Enter name:");
	sc.next();
	name=sc.next();
	System.out.println("name is:" + name);
	}
}

