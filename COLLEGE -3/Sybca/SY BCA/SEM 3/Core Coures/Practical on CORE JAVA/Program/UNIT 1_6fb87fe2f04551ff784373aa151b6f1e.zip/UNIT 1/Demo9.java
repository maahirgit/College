//check default value of all the data types
class student
{
	boolean rollno;//default value is false
	public void print()
	{
	System.out.println("\n int rollno is:"+ rollno);
	}


}


class Demo9
{
public static void main(String  args[])
{
	int x=1;
	student s1=new student();
	s1.print();
}


}
