import javax.swing.JOptionPane;

class inputdialog2
{
	public static void main(String[] arg)
	{
		String no1,no2;
		int ans,selection;
		
		no1=JOptionPane.showInputDialog(null,"please enter first number");
		no2=JOptionPane.showInputDialog(null,"please enter second number");
		
		//System.out.println(no1 + no2);
		ans=Integer.parseInt(no1) + Integer.parseInt(no2);

		System.out.println("Answer is "+ ans);
		
	}
}
