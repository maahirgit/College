class Demo7
{
	public static void main(String args[])
	{
	int x=12; //4 byte
	System.out.println("\n size of integer is:"+ (Integer.SIZE)/8);
	System.out.println("\n size of double is:"+ (Double.SIZE)/8);
	System.out.println("\n size of char is:"+ (Character.SIZE)/8);
	}

}
