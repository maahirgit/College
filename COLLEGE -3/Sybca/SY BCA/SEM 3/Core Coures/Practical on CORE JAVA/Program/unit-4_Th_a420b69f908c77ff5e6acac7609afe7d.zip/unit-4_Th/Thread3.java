//thread sleep   


   
   
   class Thread32 extends Thread
   {  
     public void run()
	     {  
		for(int i=1;i<5;i++)
		     {  
			try
			     {
					Thread.sleep(2000);
				}
			catch(InterruptedException e)
				{
					System.out.println(e);
				}
				
			System.out.println(i);  
			}  
     }  
   }  
   
class Thread31 extends Thread
   {  
     public void run()
	     {  
		
			for(int i=1;i<5;i++)
			System.out.println(i);  
			}  
     }  
    
     
class Thread3 extends Thread
{
     public static void main(String args[])
     {  
	Thread32 t1=new Thread32();  
        Thread31 t2=new Thread31();  
       
      t1.start();  
      t2.start();  
     }  
    }  