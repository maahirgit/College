import java.util.Arrays;
class arry extends Thread{

    public void run()
    {
        int arr[]={2,5,1,4,3};
        Arrays.sort(arr);
        for(int i:arr)
        {
            System.out.print(i+",");
        }

    }
}

class c_name extends Thread{
    public void run()
    {
        try
        {
            Thread.sleep(5000);
            System.out.println("GLS UNIVERCITY");
	}
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public static void main(String[] args)
    {
        arry t1=new arry();
        c_name t2=new c_name();
        t1.start();
        t2.start();
        
    }
}
