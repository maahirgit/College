
public class q_1 {
    public static void main(String[] args) {
        String s="FCAIT GLS UNIVERSITY";

        System.out.println("Lover case : "+s.toLowerCase());
        System.out.println("Find out Gls : "+s.substring(5,9));
        String s2="GLS BCA";
        System.out.println("Compper : "+s.compareTo(s2));
        System.out.println("Remove Spaces : "+s.trim());
        System.out.println("Lenght : "+s.length());
        StringBuffer s1=new StringBuffer(s);

        s1.append("JAVA CLASS");
        System.out.println("Append : "+s1);
        System.out.println("Capacity : "+s1.capacity());
        System.out.println("7 postion charector : "+s1.charAt(7));
        s1.setCharAt(7, 'M');
        System.out.println("Set charector 'M' : "+s1);

    }
}
