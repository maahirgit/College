import java.util.Scanner;

public class q1 {
    public static void main(String[] args) {
        double length,higith,b,whith,squar,rectangle,tringle;
        Scanner sc=new Scanner(System.in);

        int num;
        System.out.println("Press 1 for Rectangle");
        System.out.println("Press 2 for Squar");
        System.out.println("Press 3 for triangle");
        System.out.print("Enter a Chois : ");
        num=sc.nextInt();
        switch(num)
        {
            case 1:
            System.out.print("Enter a higth : ");
            higith=sc.nextDouble();
            System.out.print("Enter a Whith : ");
            whith=sc.nextDouble();
            rectangle=higith*whith;
            System.out.println("Area of Rectangle is : "+rectangle);
            break;

            case 2:
            System.out.print("Enter a length : ");
            length=sc.nextDouble();
            squar=4*length;
            System.out.println("Area of squar is : "+squar);
            break;

            case 3:
            System.out.print("Enter a brith : ");
            b=sc.nextDouble();
            System.out.print("Enter a hight : ");
            higith=sc.nextDouble();
            tringle=0.5*(b*higith);
            System.out.println("Area of Rectangle is : "+tringle);
            break;
        }

    }
}