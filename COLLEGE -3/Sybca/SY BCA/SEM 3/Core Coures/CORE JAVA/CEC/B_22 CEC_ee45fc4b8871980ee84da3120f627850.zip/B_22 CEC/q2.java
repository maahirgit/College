
public class q2 {

    int num1,num2;

    q2(int num1,int num2)
    {
        this.num1=num1;
        this.num2=num2;
    }

    void display()
    {
        System.out.println(num1+num2);
    }
    public static void main(String[] args) {
        q2 m=new q2(10,20);

        m.display();
    }
}