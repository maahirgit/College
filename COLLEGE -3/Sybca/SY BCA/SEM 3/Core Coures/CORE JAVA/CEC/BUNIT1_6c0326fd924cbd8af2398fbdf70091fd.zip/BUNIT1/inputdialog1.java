import javax.swing.JOptionPane;

class inputdialog1
{
	public static void main(String[] arg)
	{
		String name1;
		name1 = JOptionPane.showInputDialog(null,"Enter your name");
		System.out.println("My name is " + name1);
		
		String name2;
		name2=JOptionPane.showInputDialog(null,"Enter your name","Name",JOptionPane.QUESTION_MESSAGE);
		System.out.println("My name is " + name2);
		
		String name3;
		name3=JOptionPane.showInputDialog(null,"Enter your name","Name",JOptionPane.WARNING_MESSAGE);
		System.out.println("My name is " + name3); 
	}
}
