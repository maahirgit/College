class Demo3
{
	public static void add(int x,int y)
	{
	int c;
	c=x+y;
	System.out.println("addition is:"+c);
	}
	public static void main(String args[])
	{
	add(11,12);
	}


}
