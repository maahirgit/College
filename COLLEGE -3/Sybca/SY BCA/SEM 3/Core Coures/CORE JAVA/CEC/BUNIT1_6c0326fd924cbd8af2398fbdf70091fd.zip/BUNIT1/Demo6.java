import java.util.Scanner;
class student
{
	int rollno;
	float m1,m2;
	boolean ans;
	Scanner sc = new Scanner(System.in);
	public void getdata()
	{
	  System.out.println("\nEnter Roll No : ");
	  rollno = sc.nextInt();
	  System.out.println("\nEnter M1 No : ");
	  m1= sc.nextFloat();
	  System.out.println("\nEnter M2 No : ");
	  m2= sc.nextFloat();
	  System.out.println("\nEnter boolean : ");
	  ans= sc.nextBoolean();
	}
	public void putdata()
	{
	System.out.println("\n rollno is:"+rollno);
	System.out.println("\n m1 is:"+m1);
	System.out.println("\n m2 is:"+m2);
	}

}

class Demo6
{
	
	public static void main(String args[])
	{
	student s1=new student();
	s1.getdata();
	s1.putdata();
	}


}
