//string to int

public class StringToIntExample
{  
	public static void main(String args[])
	{  
		String s="200";  
		
		//Converting String into int using Integer.parseInt()  
		int i=Integer.parseInt(s);  

		System.out.println(s+100); 
		System.out.println(i+100);

		String str="1122";

		//Converting String into int using Integer.parseInt()  
		int inum = Integer.valueOf(str);
		System.out.println(inum); 
	}
}  
