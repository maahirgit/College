class Student1
{  
	
	int id;
	String name;  
	
	 public static void main(String args[])
	{  
		
		Student1 s1=new Student1();
		s1.id = 10;
		s1.name = "abcd";
		System.out.println(s1.id); 
		System.out.println(s1.name);  
	}  
}  