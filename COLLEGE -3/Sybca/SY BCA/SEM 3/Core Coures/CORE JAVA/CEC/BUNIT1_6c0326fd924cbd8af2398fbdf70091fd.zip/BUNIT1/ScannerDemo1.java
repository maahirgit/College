//Scanner
import java.util.*;
public class ScannerDemo1
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
	
	System.out.print("Enter name:");
        String name = sc.nextLine();
	
	System.out.print("Enter gender:");
        String gender = sc.next();
	
	System.out.print("Enter age:");
        int age = sc.nextInt();
	
	System.out.print("Enter mobile:");
        long mobileNo = sc.nextLong();
	
	System.out.print("Enter cgpa:");
        double cgpa = sc.nextDouble();
 
        System.out.println("Name: "+name);
        System.out.println("Gender: "+gender);
        System.out.println("Age: "+age);
        System.out.println("Mobile Number: "+mobileNo);
        System.out.println("CGPA: "+cgpa);
    }
}