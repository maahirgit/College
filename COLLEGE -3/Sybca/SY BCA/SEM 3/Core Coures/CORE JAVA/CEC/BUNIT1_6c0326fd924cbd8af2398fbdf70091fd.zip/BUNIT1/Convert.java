//string to int

public class Convert
{  
	public static void main(String args[])
	{  
		
		float f=23;
		System.out.println("f is:"+f);
		float f1=10.5f;
		System.out.println("f1 is:"+f1);
		int no= (int)f1;
		System.out.println(no);
		
	}	
		
}  
