import javax.swing.JOptionPane;

class Demo8
{
	public static void main(String[] arg)
	{
		int a= 10;
		JOptionPane.showMessageDialog(null,a);
	}
}
