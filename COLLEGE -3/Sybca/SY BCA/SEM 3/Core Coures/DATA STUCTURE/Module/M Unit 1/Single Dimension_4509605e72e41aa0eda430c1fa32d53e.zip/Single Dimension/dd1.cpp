
//structure 
//c structure does not allow functions to be written inside it.
//whereas C++ structure allows
//In c++ structure everthing is declared public by default thats the diff between C++ class and structure
#include

void fun();


struct demo
{
	int x,y;
	float marks[10];

	void fun() //error
	{



	}

}
void main()
{
	demo d1;
	int x,y;

}
void fun()
{



}
