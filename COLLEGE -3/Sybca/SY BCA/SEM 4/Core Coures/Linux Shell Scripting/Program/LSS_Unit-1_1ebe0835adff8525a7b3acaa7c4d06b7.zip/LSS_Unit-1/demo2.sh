a=10
b=20
val=`expr $a + $b`
echo "sum is :$val"
val=`expr $a - $b`
echo "sub is :$val"
val=`expr $a \* $b`
echo "mul is :$val"
val=`expr $a / $b`
echo "div is :$val"
val=`expr $a % $b`
echo "modular is :$val"



