echo "MENU"
echo "1. ADDITION"
echo "2. SUB"
echo "3. MUL"
echo "4. DIV"
echo "Enter ur choice:"
read ch
echo "enter no1:"
read a
echo "enter no2:"
read b
case $ch in
1)
	echo "sum is:" + $(($a + $b))
;;
2)
	echo "sub is:" + $(($a - $b))
;;
*)
	echo "enter valid coice"
;;
esac
































