str1="GLS"
str2="BCA"
str3=""
if [ $str1 = $str2 ] 
then
echo "$str1=$str2:str1 is equal to str2"
else
echo "str1 is not equal to str2"
fi

if [ $str1 != $str2 ] 
then
echo "$str1!=$str2:str1 is not equal to str2"
else
echo "str1 is equal to str2"
fi

if [ $str3 ]
then
echo "str3 is not empty"
else
echo "str3 is empty"
fi

if [ -z $str1  ] 
then
echo "$str1:str1 length is zero"
else
echo "$str1:str1 length is not zero"
fi

if [ -n $str1  ] 
then
echo "$str1:str1 length is not zero"
else
echo "$str1:str1 length is zero"
fi