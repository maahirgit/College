echo "enter no 1"
read a
echo "enter no 2"
read b
echo "enter no 3"
read c

echo $a $b $c

if test $a -gt $b -a $a -gt $c
then
	echo "A is bigger"
elif test $b -gt $a -a $b -gt $c
then
	echo "B is Bigger"
else
	echo "C is Bigger"
fi




#
#if [ $a -eq $b ]
#then
#	echo "both are same"
#else
#	echo "both r not equal"
#fi























