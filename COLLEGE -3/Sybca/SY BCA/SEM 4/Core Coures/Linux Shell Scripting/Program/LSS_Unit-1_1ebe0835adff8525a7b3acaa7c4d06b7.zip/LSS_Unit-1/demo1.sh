a=10
b=2
val=$(($a+$b))
echo "Sum is :$val"
