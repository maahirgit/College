echo enter a value
read a
echo enter another number
read b

if test  $a -lt $b 
then

 echo $a is less than $b

elif test $a -gt $b
then

 echo $a is greater than $b

else

 echo both are equal 
fi

