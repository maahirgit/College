echo "Default behavior of Awk : By default Awk prints every line of data from the specified file."
echo "\n"
awk '{print}' marks.txt
echo "________"

echo "Print the lines which matches with the given pattern."
echo "\n"
awk '/Mat/ {print}' marks.txt 
echo "________"

echo "Splitting a Line Into Fields"
echo "\n"
awk '{print $2,$4}' marks.txt  
echo "________"

echo "Printing Lines with More than 25 Characters"
echo "\n"
awk 'length > 25' marks.txt
echo "________"

echo "Printing Column in Any Order" 
echo "You can print columns in any order."
echo " For instance, the following example prints the fourth column followed by the third column."
echo "\n"
awk '/Eng/ {print $4 "\t" $3}' marks.txt
echo "________"









