#Display character class
grep "[aA]g[ar][ra]wal" bre.txt
echo "\n"

agarwal
agrawal
Agrawal
Agarwal


# Display single character p,q,r
grep [pqr] bre.txt
echo "\n"

# Display starting character with p,q,r
grep ^[pqr] bre.txt
echo "\n"

# Display single character which is not a p,q,r
grep [^pqr] bre.txt
echo "\n"

#Display digit between 1-3
grep [1-3] bre.txt
echo "\n"

#Display non-alphabatically character
grep [^a-zA-Z] bre.txt
echo "\n"

#Display pattern that starts at the begining of the line
grep ^p bre.txt
echo "\n"
grep "^2" bre.txt
echo "\n"

#Display pattern that match at the end of line
grep wal$ bre.txt
echo "\n"

# Display search for the lines which starts with a number.
grep "^[0-9].*" bre.txt
echo "\n"

#Display lines with exactly one character
grep "^.$" bre.txt
echo "\n"

#Display any number of character or none after "ag"
grep ag.* bre.txt
echo "\n"

#Display or match a single character of any value, except end of line. 
grep "a." bre.txt
echo "\n"

#Display or match zero or more of the preceding character or expression. 
grep "a*" bre.txt
echo "\n"
