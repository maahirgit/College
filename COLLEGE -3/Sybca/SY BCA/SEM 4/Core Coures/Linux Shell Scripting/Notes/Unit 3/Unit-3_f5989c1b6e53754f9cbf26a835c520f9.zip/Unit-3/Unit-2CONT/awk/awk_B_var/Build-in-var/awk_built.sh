echo "RLENGTH - MATCH LENGTH"
awk 'BEGIN { if (match("One Two Three", "re")) { print RLENGTH } }'

echo "FILENAME"
awk 'END {print FILENAME}' marks.txt

echo "ARGC - number of arguments provided at the command line."
awk 'BEGIN {print "Arguments =", ARGC}' One Two Three Four

echo "ARCV"
awk 'BEGIN { 
   for (i = 0; i < ARGC - 1; ++i) {  
      printf "ARGV[%d] = %s\n", i, ARGV[i] 
   } 
}' one two three four     

echo "ERRNO"
awk 'BEGIN { ret = getline < "mak.txt"; if (ret == -1) print "Error:", ERRNO }'

echo "CASE"
awk 'BEGIN{IGNORECASE = 1} /amit/' marks.txt

awk 'BEGIN{IGNORECASE = 0} /amit/' marks.txt









