#Use of NR built-in variables (Display Line Number)

awk '{print NR,$0}' employee.txt 

#Use of NF built-in variables (Display Last Field)

awk '{print $1,$NF}' employee.txt 

#Another use of NR built-in variables (Display Line From 3 to 6)

awk 'NR==3, NR==6 {print NR,$0}' employee.txt 



