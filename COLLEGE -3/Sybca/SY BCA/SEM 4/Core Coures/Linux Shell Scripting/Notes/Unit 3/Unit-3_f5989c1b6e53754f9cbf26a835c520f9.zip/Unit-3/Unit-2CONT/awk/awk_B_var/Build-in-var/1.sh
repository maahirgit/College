awk 'BEGIN {
	for(i = 0; i < ARGC - 1; ++i) {
		printf "ARGV[%d] = %s\n", i, ARGV[i]
	}
}' Vidhi SY BCA LSS
echo $1






