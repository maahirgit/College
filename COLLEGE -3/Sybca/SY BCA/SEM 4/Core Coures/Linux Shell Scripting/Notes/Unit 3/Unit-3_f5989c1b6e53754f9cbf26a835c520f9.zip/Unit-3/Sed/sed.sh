#sed Command

#Replacing or substituting string
sed 's/unix/linux/1' file1.txt

#Replacing the nth occurence of a pattern in a line
sed 's/unix/linux/2' file1.txt

#Replacing all the occurence of the pattern in a line
sed 's/unix/linux/g' file1.txt

#Replacing from nth occurences to all occurrences in a line
sed 's/unix/linux/2g' file1.txt

echo " \n other file"

#Using & as the matched string
sed 's/unix/{&}/g' file1.txt

