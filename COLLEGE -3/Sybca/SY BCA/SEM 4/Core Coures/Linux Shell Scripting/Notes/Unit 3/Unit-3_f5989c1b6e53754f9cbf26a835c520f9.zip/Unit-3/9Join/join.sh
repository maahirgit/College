echo "join two files"
join foodtypes.txt foods.txt



echo "join files on diffrent fields"
join -1 1 -2 2 foodtypes.txt review.txt

join -1 2 -2 1 foodtypes.txt review.txt
