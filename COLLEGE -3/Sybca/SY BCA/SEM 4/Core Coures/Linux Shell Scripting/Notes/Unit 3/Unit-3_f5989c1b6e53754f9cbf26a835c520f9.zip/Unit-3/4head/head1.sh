# By default prints the first 10 lines from a  file
head  head.txt
echo "prints the first n lines from a file"
head -n 3 head.txt

echo "Print Middle lines (5,6)"
head -6 head.txt | tail -2

