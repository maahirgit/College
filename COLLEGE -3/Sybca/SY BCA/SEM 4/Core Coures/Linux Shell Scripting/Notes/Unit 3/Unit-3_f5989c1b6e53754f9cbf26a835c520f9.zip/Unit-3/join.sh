echo "join two files"
join foodtypes.txt foods.txt

echo " _____________________________________________________________________"
echo " join files on diffrent fields"
join -1 1 -2 2 foodtypes.txt review.txt
