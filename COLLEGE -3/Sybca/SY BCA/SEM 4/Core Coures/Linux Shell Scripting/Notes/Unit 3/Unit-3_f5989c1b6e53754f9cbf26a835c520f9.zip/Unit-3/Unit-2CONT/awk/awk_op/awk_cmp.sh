awk '$3 <= 30 { printf "%s\t%s\n", $0,"**" ; } $3 > 30 { print $0 ;}' food.txt

awk '$3 <= 20 { printf "%d\t%s\n", $0,"**" ; } $3 > 30 { print $0 ;}' food.txt
