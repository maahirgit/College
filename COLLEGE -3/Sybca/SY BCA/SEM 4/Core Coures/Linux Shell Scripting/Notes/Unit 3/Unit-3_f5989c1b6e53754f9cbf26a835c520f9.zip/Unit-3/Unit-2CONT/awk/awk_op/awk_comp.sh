awk '$3 > 30 { print $2 ;} ' food.txt
echo "____________________"

awk '$3 <= 30 { printf "%s\t%s\n", $0,"**" ; } $3 > 30 { print $0 ;}' food.txt 
echo "____________________"

awk '$3 < 30 { printf "%s\t%s\n", $0,"**" ; }' food.txt 
echo "____________________"

awk '{printf "%d\n", $1}' food.txt
echo "____________________"

awk '{printf "%c\n",$1}' food.txt
echo "____________________"

awk '{printf "%.2f\n",$1}' food.txt
echo "____________________"

awk '{printf "%d%d%d\n", $2,$3,$4}' food.txt







