echo "matches any number of characters, or none"
grep "K.*" marks.txt

echo "_____________________________"
echo "Matches any character"
grep [AR] marks.txt

echo "_____________________________"
echo " matches range of characters" 
grep [A-K] marks.txt

echo "____________________________"
echo " Matches any number " 
grep [1-3] marks.txt

echo " _________________________"
echo "Matches 1 at starting"
grep "^1" marks.txt









