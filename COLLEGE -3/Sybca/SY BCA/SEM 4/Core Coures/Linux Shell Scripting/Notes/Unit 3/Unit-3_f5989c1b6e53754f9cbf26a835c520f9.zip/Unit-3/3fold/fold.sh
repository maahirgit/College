#Limit column width
https://shapeshed.com/unix-fold/
fold -w 10 foldfile.txt
echo "\n"
#Limit width by bytes
fold -bs20 foldfile.txt
echo "\n"
#Wrap on spaces
fold -w 20 -s foldfile.txt
echo "\n"
