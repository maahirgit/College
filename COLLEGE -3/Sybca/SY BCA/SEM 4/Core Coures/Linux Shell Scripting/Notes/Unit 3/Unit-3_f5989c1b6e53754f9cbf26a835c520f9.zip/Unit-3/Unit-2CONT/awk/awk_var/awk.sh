echo "\n Print 1st and 3rd column"
awk '{print $1 "\t" $3}' marks.txt

echo "\nPrint Columns in any order"
awk '/a/ {print $4 "\t" $1}' marks.txt

echo "\n Print Lines with more than 18 characters"
awk 'length($0) > 30' marks.txt
