awk '$3 > 30 { print $2 ;} ' food.txt

echo "\n"

echo "hello"

awk '$3 < 30 { printf "%-25s\t%s\n", $0,"**" ; } ' food.txt #String
awk '$3 < 30 { printf "%c\t%s\n", $0,"**" ; } ' food.txt #ASCII number character
awk '{printf "%d%d%d\n", $2,$3,$4}' file name
awk '{printf "%s\t %d\n", $1,$2}' file name
awk '$3 < 30 { printf "%d\t%s\n", $0,"**" ; } ' food.txt #Decimal

awk '$3 < 30 { printf "%2f\t%s\n", $0} ' food.txt #floating number
awk '{printf "%d%d%d\n", $2,$3,$4}' food.txt
awk '{printf "%d\n", $1}' food.txt
awk '{printf "%c\n",$1}' food.txt
awk '{printf "%.2f\n",$1}' food.txt


