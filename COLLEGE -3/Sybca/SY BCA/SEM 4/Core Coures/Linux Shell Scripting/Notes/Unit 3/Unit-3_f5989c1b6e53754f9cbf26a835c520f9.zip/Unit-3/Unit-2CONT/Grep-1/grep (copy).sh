# searching the file ignoring the case 

cat file2.txt
echo "____________"
grep -i "Unix" file2.txt

echo "counting number of lines  matched \n"

grep -i -c "Unix" file2.txt

echo  "\nchecking the whole words in the file "

echo "case check"
grep -w "unix" file2.txt

echo "\n display line number while displaying output n case sensitive"

grep -n "unix" file2.txt

echo "inverting the pattern matched/ displaying lines which are not matched n case sensitive"

grep -v "unix" file2.txt

echo "________multiple search______"

grep -e "opensource" -e "powerful" file2.txt








