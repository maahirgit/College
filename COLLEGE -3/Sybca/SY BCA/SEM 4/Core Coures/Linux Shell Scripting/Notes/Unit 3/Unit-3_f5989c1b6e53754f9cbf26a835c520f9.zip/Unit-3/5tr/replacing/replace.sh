# translate with file
tr 'sumit' 'smit' < file.txt
