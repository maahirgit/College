#continue skips current iteration.
i=0
while [ $i -lt 5 ] 
do
 i=$(($i+1))
 if [ $i -eq 2 ]
then
continue
fi
echo "Number : $i"
done

