#continue skips current iteration.

nums="1 2 3 4 5 6 7"
for num in $nums
do
  no=` expr $num % 2 `
  if [ $no -eq 0 ]
  then
	echo "$num Number is even number"
	continue
  fi
echo "$num is Odd number"
done


