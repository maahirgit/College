#The while loop is perfect for a situation where you need to execute a set of commands 
#while some condition is true. 
#Sometimes you need to execute a set of commands until a condition is true.
i=0
until [ $i -eq 5 ]
do
 echo $i
  i=$((i+1))
done

