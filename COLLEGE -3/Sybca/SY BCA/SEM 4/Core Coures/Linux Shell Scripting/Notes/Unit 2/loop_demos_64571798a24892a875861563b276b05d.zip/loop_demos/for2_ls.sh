count=1
for i in `ls`
do 
	if test -f $i
	then
		count=`expr $count + 1`
	fi
done
echo "Total :"$count

