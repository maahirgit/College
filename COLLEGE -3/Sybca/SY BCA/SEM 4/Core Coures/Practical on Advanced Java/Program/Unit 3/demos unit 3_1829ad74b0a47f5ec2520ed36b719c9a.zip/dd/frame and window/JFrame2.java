import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.*;

class Winclose extends WindowAdapter
{
    	public void windowClosing(WindowEvent we)
	{
		System.exit(0);
	}



}//end of winclose class

class JFrame2
{
	public static void main(String args[])
	{
		JFrame fb = new 1JFrame();
		Winclose wc = new Winclose();
		fb.addWindowListener(wc);
		
		fb.setTitle("JFrame can close");
		fb.setSize(600,400);
		fb.setVisible(true);
		fb.setLocation(200,300);
	}
}//end of class JFrame2




