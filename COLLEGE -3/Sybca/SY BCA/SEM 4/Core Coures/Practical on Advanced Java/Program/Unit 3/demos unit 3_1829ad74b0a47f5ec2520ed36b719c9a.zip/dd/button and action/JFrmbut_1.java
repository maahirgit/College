import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class JBtn_1 extends JFrame
{
	JButton b1,b2,b3;
	Container con;
	JBtn_1(String s)
	{
		super(s);
		setSize(250,150);
		con = getContentPane();
		FlowLayout f1=new FlowLayout(FlowLayout.LEFT);
		con.setLayout(f1);
		b1= new JButton("ZERO");
		b2= new JButton("ONE");
		b3= new JButton("TWO");
		con.add(b1);
		con.add(b2);
		con.add(b3);
	
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});

		b1.addActionListener(new ActionListener()
		{  
			public void actionPerformed(ActionEvent e)
			{  
            			System.out.println(e.getActionCommand());  
        		}  
    		});  
		b2.addActionListener(new ActionListener()
		{  
			public void actionPerformed(ActionEvent e)
			{  
            			System.out.println(e.getActionCommand());  
        		}  
    		});  
	}	

}
class JFrmbut_1
{
	public static void main(String args[])
	{
		JBtn_1 fb = new JBtn_1("Button Demo");
		fb.setVisible(true);
	}

}//end of class JFrame2









