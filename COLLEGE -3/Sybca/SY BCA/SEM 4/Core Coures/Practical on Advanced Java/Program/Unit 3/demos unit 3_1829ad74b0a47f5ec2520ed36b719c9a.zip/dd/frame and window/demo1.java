import javax.swing.*;
import java.awt.*;    
import java.awt.event.*;
  

public class demo1 extends JFrame implements WindowListener {    
  

    demo1() {   
  

        addWindowListener(this);   
     
        setSize (400, 400);    
        setLayout (null);    
        setVisible (true);    
    }   

public static void main(String[] args) {    
    new demo1();    
}    
  

public void windowActivated (WindowEvent wc) {    
    System.out.println("activated");    
}    
  

public void windowClosed (WindowEvent wc) {    
    System.out.println("closed");    
}    
  

public void windowClosing (WindowEvent wc) {    
    System.out.println("closing");    
    dispose();    
}    
  

public void windowDeactivated (WindowEvent wc) {    
    System.out.println("deactivated");    
}    

public void windowDeiconified (WindowEvent wc) {    
    System.out.println("deiconified");    
}    
  

public void windowIconified(WindowEvent wc) {    
    System.out.println("iconified");    
}    
  

public void windowOpened(WindowEvent wc) {    
    System.out.println("opened");    
}  
}
