import javax.swing.*;
import java.awt.*;  
import java.awt.event.*;  

class Winclose extends WindowAdapter
{
    	public void windowClosing(WindowEvent we)
	{
		System.exit(0);
	}
}//end of winclose class

public class MouseListenerExample2 extends JFrame implements MouseListener
{  
   	MouseListenerExample2()
	{  
		Winclose wc = new Winclose();
		addWindowListener(wc);
		   //  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        	addMouseListener(this);  
          	setTitle("Mouse Event");
        	setSize(300,300);  
        	setLayout(null);  
        	setVisible(true);  
    	}  
    
	public void mouseClicked(MouseEvent e)
	{  
        	Graphics g=getGraphics();  
        	g.setColor(Color.BLUE);  
        	g.fillOval(e.getX(),e.getY(),30,130);  
    	}  
    
	public void mouseEntered(MouseEvent e) 
	{
		System.out.println("Mouse Entered in Frame");
	}  
    	public void mouseExited(MouseEvent e) 
	{
		System.out.println("Mouse Exited from the Frame");
	}  
    	public void mousePressed(MouseEvent e) 
	{
		System.out.println("Mouse Clicked");
	}  
    	public void mouseReleased(MouseEvent e) 
	{
		System.out.println("Mouse click released");
	}  
      
	public static void main(String[] args) 
	{  
    		new MouseListenerExample2();  
		
	}  
}  
