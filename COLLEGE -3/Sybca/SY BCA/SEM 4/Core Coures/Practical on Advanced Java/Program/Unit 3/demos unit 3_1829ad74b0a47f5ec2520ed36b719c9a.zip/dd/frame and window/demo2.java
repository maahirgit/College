import javax.swing.*;
import java.awt.event.*;


class demo2 extends JFrame
{
	demo2()
	{
	setTitle("title2");
	setVisible(true);
	setSize(200,200);
	setLocation(300,400);
	
	}
	public static void main(String args[])
	{
	new demo2();

	}

}
