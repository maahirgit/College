import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class demo5 extends JFrame implements ActionListener
{
	JLabel l1;
	JButton b1,b2;
	demo5()
	{
	setSize(250,250);
	setVisible(true);
	setTitle("Calculator");
	FlowLayout f1=new FlowLayout(FlowLayout.CENTER);
   	setLayout(f1);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	l1=new JLabel("Image");
	b1=new JButton("APPLE");
	b2=new JButton("BANANA");
	b1.addActionListener(this);
	b2.addActionListener(this);
	add(b1);
	add(b2);
	add(l1);
	}
	public void actionPerformed(ActionEvent ae)
	{	
		String s=ae.getActionCommand();
		if(s=="APPLE")
		{
		ImageIcon i1=new ImageIcon("apl.jpeg");
		l1.setIcon(i1);
		//l1.setText("Apple");
		}
		if(s=="BANANA")
		{
		ImageIcon i1=new ImageIcon("banana.jpeg");
		l1.setIcon(i1);
	
		l1.setText("BANANA");
		}

	}
	public static void main(String args[])
	{
	new demo5();
	}

}
