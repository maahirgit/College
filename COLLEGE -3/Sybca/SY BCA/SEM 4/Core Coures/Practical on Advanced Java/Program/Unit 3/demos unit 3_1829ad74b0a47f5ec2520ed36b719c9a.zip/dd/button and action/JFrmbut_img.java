import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class JBtn_1 extends JFrame implements ActionListener
{
	JButton b1;
	Container con;
	JBtn_1(String s)
	{
		super(s);
		setSize(500,500);
		con = getContentPane();
		con.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		ImageIcon img = new ImageIcon("apl.jpeg");
		b1= new JButton("Image display",img);
		b1.addActionListener(this);
		con.add(b1);

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});
		
	}
	public void actionPerformed(ActionEvent e)
	{  
        	ImageIcon img = new ImageIcon("btn_img2.jpg");
		b1.setIcon(img);
		System.out.println(e.getActionCommand());  
        }  	

}
class JFrmbut_img
{
	public static void main(String args[])
	{
		JBtn_1 fb = new JBtn_1("Button Demo");
		fb.setVisible(true);
	}

}//end of class JFrame2





