import javax.swing.*;

class JFrame1
{
	public static void main(String args[])
	{
		JFrame f = new JFrame("Blank Frame");
		f.setTitle("hello");
		f.setSize(400,400);
		f.setVisible(true);
		f.setLocation(100,300);
		
	}

}//end of class JFramlbl
