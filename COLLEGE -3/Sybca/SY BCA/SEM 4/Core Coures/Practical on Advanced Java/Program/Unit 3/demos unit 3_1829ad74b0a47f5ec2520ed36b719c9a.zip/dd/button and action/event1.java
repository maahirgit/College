
import java.awt.*;  
import java.awt.event.*;  
import javax.swing.*;
class event1 extends JFrame implements ActionListener
{  
	JTextField tf;  
	JButton b;
	event1()
	{  
		tf=new JTextField(50);  
		tf.setBounds(60,50,170,20);  
		b=new JButton("click me");  
		b.setBounds(100,120,80,30);  
		b.addActionListener(this);
		add(b);
		add(tf);  
		setSize(300,300);  
		setLayout(null);  
		setVisible(true);  
	}  
	public void actionPerformed(ActionEvent e)
	{  
		tf.setText("Welcome");  
	}  
	public static void main(String args[])
	{  
		new event1();  
	}  
}  
