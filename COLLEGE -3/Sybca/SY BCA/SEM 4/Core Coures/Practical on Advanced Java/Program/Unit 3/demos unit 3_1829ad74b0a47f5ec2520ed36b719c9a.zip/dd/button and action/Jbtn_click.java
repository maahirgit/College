/* THIS JAVA PROGRAMME CODE WILL TAKE THE TEXT FROM THE TEXT FILED AND DISPLAY INTO LABEL USING BUTTON CLICK */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Jbtn_click extends JFrame implements ActionListener
{
	JTextField t1;	
	JButton b1;
	JLabel lbl1,lbl2;
	
	Container con;
	Jbtn_click(String s)
	{
		super(s);
		setSize(300,200);
		con = getContentPane();
		con.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		
		lbl2 = new JLabel("Enter you Name ->");
		con.add(lbl2);
		
		t1 = new JTextField(10);
		con.add(t1);

		b1= new JButton("Submit");
		b1.addActionListener(this);
		con.add(b1);
		
		lbl1 = new JLabel("Your Name is :");
		con.add(lbl1);
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent we)
			{
				System.exit(0);
			}
		});
			
	}
	
	public void actionPerformed(ActionEvent e)
	{  
		lbl1.setText("YOUR Name is : " + t1.getText());
		System.out.println(e.getActionCommand());
        }  	

}
class JFrmlbl_1
{
	public static void main(String args[])
	{
		Jbtn_click fb = new Jbtn_click("Button Click");
		fb.setVisible(true);
	}

}//end of class JFrame2
