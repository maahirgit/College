import java.util.*;

public class Hashmap1
{
	public static void main(String args[])
	{

		HashMap<Integer, String> hmap = new HashMap<Integer, String>();
 		 
		/*Adding elements to HashMap*/
      	
		hmap.put(12, "Chaitanya");
     		hmap.put(2, "Rahul");
      		hmap.put(7, "Singh");
     		hmap.put(49, "Ajeet");
      		hmap.put(2, "Anuj");
		hmap.put(5, "Rahul");
		System.out.println(hmap);

		for(Map.Entry m:hmap.entrySet())
		{  
   			System.out.println("key="+m.getKey()+" value="+m.getValue());  
  		}  
	}
}










