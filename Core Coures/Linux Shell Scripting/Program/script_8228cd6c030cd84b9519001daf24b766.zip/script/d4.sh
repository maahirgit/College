name="vidhi"
no=12

echo $name $no
