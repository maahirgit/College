a=10
b=20

if [$a == $b]
then
   echo "a is equal to b"
fi

