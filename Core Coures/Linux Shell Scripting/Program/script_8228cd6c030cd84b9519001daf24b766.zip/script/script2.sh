# shell script
a=10
b=20

sum=`expr $a + $b`
echo $sum

sum=`expr $a - $b`
echo $sum


sum=`expr $a \* $b`
echo $sum

sum=`expr $a / $b`
echo $sum

sum=`expr $a % $b`
echo $sum
