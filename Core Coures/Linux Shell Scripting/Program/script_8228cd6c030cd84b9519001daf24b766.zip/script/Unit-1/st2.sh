a=10
b=20
if [ $a -eq $b ]
then
	echo a and b
else
	echo not
fi


