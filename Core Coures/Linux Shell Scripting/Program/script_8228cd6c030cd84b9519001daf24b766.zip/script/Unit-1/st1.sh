echo enter a value
read a
echo enter another number
read b

if test $a -ne $b
then  
	echo "a is smaller than b"
fi



