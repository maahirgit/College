echo "enter first file"
read file1
echo "enter second file"
read file2
if test -f $file1 -a -f $file2
then 
	echo "both exist"
	cat $file1 >> $file2
	cat $file2
else
	echo "not exist"
fi
