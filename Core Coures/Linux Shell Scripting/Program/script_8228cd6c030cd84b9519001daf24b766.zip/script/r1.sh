echo "hello"

name ="GLS UNIVERSITY"

echo "college name is:" $name
