date
pwd
ls
