echo "Enter no"
read no
echo $no

