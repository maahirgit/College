echo "enter name:"
read name

echo $name
