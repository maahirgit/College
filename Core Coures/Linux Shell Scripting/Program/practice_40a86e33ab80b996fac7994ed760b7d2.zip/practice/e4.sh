for line in $(ls)
do 

echo $line	
cat $line | wc -c
	

done



