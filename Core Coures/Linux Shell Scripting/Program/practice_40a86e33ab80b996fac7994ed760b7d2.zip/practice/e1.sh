echo "Enter char:"
read ch
ls -l | tr -s " " | cut -d " " -f9 | grep "^$ch" |tr "[a-z]" "[A-Z]"
