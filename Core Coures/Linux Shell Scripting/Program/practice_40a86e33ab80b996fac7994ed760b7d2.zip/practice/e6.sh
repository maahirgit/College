t=`ls -lS|tr -s " " | cut -d  " " -f5 | head -n 2`

echo `ls -lS | grep $t | tr -s " " | cut -d  " " -f9`	
