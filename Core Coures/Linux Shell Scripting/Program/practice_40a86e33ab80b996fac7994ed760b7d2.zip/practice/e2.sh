echo "Enter content press ctrl +d to end file"
cat > file1
echo "file is:"
cat file1
