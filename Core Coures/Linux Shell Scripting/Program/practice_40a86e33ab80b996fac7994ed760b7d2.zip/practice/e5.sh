echo `cut -c 6-15 c1.txt |sort | uniq`
