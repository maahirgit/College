echo "ENter char"
read ch
echo `ls -l | tr -s " " | cut -d " " -f9 | grep "^$ch"`
