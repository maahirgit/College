echo $1
cat $1 | tr "[a-z]" "[A-Z]"
