echo "enter file name:"
read file1
echo `cut -d " " -f1 $file1 |head -n 2`
