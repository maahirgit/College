echo "Enter file"
read file1
echo "enter pattern"
read srch
t=`grep $srch $file1`
echo $t
echo `grep -c $srch $file1`


