if test -f $1
then
echo $1 "is file"
fi

