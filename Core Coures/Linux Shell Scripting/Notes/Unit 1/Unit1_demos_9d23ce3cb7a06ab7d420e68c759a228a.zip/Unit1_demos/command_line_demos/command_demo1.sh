echo "total number of arguments are "$#
echo "arguments are "$*
echo "file Name is : "$0
#echo "The passed arguments are : $1,$2,$3"



