echo "enter first file"
read file1
echo "enter second file"
read file2
if test -f $file1 -a -f $file2
then 
	echo "both exist"
	cat $file1 >> $file2
	cat $file2 #display file2 data
else
	echo "not exist"
fi
#test validate expression or test the condition



