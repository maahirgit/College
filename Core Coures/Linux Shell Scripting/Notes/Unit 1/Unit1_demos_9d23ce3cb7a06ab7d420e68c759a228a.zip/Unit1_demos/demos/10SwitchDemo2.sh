echo "Enter color name"
read color
case $color in
"red")
echo "You selected red color"
;;
"blue")
echo "You selected blue color"
;;
"pink")
echo "You selected pink color"
;;
*)
echo "By default color is black"
;;
esac













