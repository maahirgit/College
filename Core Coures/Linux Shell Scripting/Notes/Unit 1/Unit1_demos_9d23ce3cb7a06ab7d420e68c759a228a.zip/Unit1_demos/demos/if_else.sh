no1=10
no2=10
if [ $no1 -eq $no2 ]
then 
    echo "Both variables are the same"
else
    echo "Both variables are different"
fi
