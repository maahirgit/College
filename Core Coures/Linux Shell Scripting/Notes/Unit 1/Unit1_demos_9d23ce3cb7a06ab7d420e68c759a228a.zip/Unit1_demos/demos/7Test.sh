a=150
b=100
test $a -gt $b  && echo "Yes"
