import java.util.*;
class Demo2
{
		public static void main(String[] args)
		{
		int x[]=new int[5];
		Scanner sc=new Scanner(System.in);

		for(int i=0;i<x.length;i++)
		{
			System.out.println("ENter value:");
			x[i]=sc.nextInt();	
			x[i]=x[i]+2;
		}
		for(int no:x)
		{
			System.out.println(no);

		}




		}
}
