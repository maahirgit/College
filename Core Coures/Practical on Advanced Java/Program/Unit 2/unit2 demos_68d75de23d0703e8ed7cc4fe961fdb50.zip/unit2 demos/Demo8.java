import java.util.*;

class Demo8
{
		public static void main(String args[])
		{	
		LinkedList<String> L1=new LinkedList<String>();
		L1.add("item1");
		L1.add("item2");
		L1.add("item3");
		L1.add("item4");
		L1.add("item5");
			Iterator<String> I1=L1.iterator();
			while(I1.hasNext())
				{
					System.out.println(I1.next());
				}

			ListIterator<String> LI1=L1.listIterator();
			while(LI1.hasNext())
				{
					System.out.println(LI1.next());
				}
		}


}
