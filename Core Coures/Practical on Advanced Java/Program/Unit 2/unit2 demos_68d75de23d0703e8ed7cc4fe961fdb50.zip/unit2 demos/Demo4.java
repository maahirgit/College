import java.util.*;

class Demo4
{
		public static void main(String args[])
		{	
		ArrayList<String> A1=new ArrayList<String>(5);
		A1.add("item1");
		A1.add("item2");
		A1.add("item3");
		A1.add("item4");
		A1.add("item5");
		A1.add(5,"item6");
		System.out.println(A1);
		System.out.println("\n size of A1 is:" + A1.size());
		A1.remove(1);
		A1.set(4,"item60");
		System.out.println("Item at index 3 is:"+A1.get(3));
				System.out.println(A1);
		}


}
