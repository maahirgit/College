import java.util.*;  
public class ListDemo4
{  
public static void main(String args[])
{  
	ArrayList<String> al=new ArrayList<String>();  
	al.add("Amit");  
	al.add("Vijay");  
	al.add("Kumar");  
	al.add(1,"Sachin");  
	System.out.println(al);
		for(int i=0;i<=3;i++)
		{
			System.out.println("element at: "+ al.get(i));
		}

	  
	ListIterator<String> itr=al.listIterator();  
	System.out.println("traversing elements in forward direction...");  
	while(itr.hasNext())
	{  
		System.out.println(itr.next());  
	}  
	System.out.println("traversing elements in backward direction...");  
	while(itr.hasPrevious())
	{  
		System.out.println(itr.previous());  
	}  
}  
}  






