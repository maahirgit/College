import java.util.*;

class Demo5
{
		public static void main(String args[])
		{	
		ArrayList<String> A1=new ArrayList<String>(5);
		List<String> A2=new ArrayList<String>();
		A1.add("item1");
		A1.add("item2");
		A1.add("item3");
		A1.add("item4");
		A1.add("item1");
		A1.add(5,"item6");
		System.out.println(A1);
		System.out.println("A1");
		System.out.println("A2");
		A2=A1.subList(1,4);
		System.out.println(A2);
		System.out.println(A1.indexOf("item1"));
		System.out.println(A1.lastIndexOf("item1"));
		for(int i=0;i<A1.size();i++)		
			System.out.println("\n "+ A1.get(i));
			


	











		}


}
