import java.util.*;

class Demo3
{
	public static void main(String args[])
	
	{
		ArrayList<String> a1=new ArrayList<String>(5);
		a1.add("item1");
		a1.add("item2");
		a1.add("item3");
		a1.add("item4");
		a1.add("item5");

		System.out.println(a1);

		for(int i=0;i<a1.size();i++)
		{
			System.out.println(a1.get(i));
		}
		System.out.println("ListIterator");
		ListIterator<String> list1=a1.listIterator();
		while(list1.hasNext())
		{
			System.out.println(list1.next());
		}
		System.out.println("ListIterator previous");
		while(list1.hasPrevious())
		{
			System.out.println(list1.previous());
		}
		

	}
}
