class Demo1
{
		public static void main(String[] args)
		{
		int x[]={11,23,45,56,67};

		for(int i=0;i<x.length;i++)
			System.out.println(x[i]);

		}
}
