import java.util.*;

class Demo6
{
		public static void main(String args[])
		{	
		ArrayList<String> A1=new ArrayList<String>(5);
		A1.add("item1");
		A1.add("item2");
		A1.add("item3");
		A1.add("item4");
		A1.add("item1");
		A1.add(5,"item6");

		ListIterator<String> list1=A1.listIterator();
		while(list1.hasNext())
		{
		System.out.println(list1.next());
		}
		System.out.println("ulta");
		while(list1.hasPrevious())
		{
		System.out.println(list1.previous());
		}




















		
			


	











		}


}
