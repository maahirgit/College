import java.util.*;

class Demo7
{
		public static void main(String args[])
		{	
		LinkedList<String> L1=new LinkedList<String>();
		L1.add("item1");
		L1.add("item2");
		L1.add("item3");
		L1.add("item4");
		L1.add("item1");
		L1.add(5,"item6");
		L1.addFirst("item0");
		L1.addLast("item10");
		L1.remove("item0");
		L1.remove(1);
		for(String S:L1)
		{
			System.out.println(S);
		}
		for(int i=0;i<L1.size();i++)
		{
			System.out.println(L1.get(i));
		}
		System.out.println(L1.contains("item3"));
		System.out.println(L1.getFirst());
		System.out.println(L1.getLast());
		}


}
