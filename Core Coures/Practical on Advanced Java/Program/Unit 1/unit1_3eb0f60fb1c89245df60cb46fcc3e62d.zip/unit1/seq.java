import java.io.*;

class  seq
{
	public static void main(String args[]) throws Exception
	{
			File f1=new File("test1.dat");
		


	}




}
