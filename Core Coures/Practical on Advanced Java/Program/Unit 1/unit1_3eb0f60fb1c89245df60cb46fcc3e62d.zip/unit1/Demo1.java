import java.io.*;

class Demo1
{
	public static void main(String args[])
	{
	try
	{
		File F1=new File("B1.dat");
		FileOutputStream fos=new FileOutputStream(F1);
		FileOutputStream fos1=new FileOutputStream("odd.dat");
		FileInputStream fis=new FileInputStream(F1);
		for(int i=1;i<=30;i++)
		{
		fos.write(i);
		}
		fos.close();
		int c;
		while((c=fis.read())!=-1)
		{
		if(c%2==1)
			fos1.write(c);
		}
		fis.close();
	}
	catch (Exception e)
	{	
		System.out.println("Error");
	}
	}

}





