import java.io.*;

class Readbyte
{
	public static void main(String args[])
	{
		try
		{
			int c;
			FileInputStream fis = new FileInputStream("abc.dat");
			while((c=fis.read())!=-1)
			{
			System.out.print((char) c);
			}
	
		}
		catch(IOException e)
		{	
			System.out.println(e);
			System.out.println("error generated ..!");
		}
	}
}
