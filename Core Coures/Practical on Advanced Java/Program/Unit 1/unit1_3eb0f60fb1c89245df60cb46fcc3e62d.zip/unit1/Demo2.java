import java.io.*;

class Demo2
{
	public static void main(String args[])
	{
	try
	{
			InputStream is=System.in;
			OutputStream os=System.out;
			int c;
			while((c=is.read())!=65)
			{	
			
			os.write(c);

			}
	}
	catch (Exception e)
	{	
		System.out.println("Error");
	}
	}

}





