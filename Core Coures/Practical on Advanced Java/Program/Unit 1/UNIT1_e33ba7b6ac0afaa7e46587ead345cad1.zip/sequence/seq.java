import java.io.*;

class  seq
{
	public static void main(String args[]) throws Exception
	{
			File f1=new File("test1.dat");
			File f2=new File("test2.dat");
			FileInputStream fis1=new FileInputStream(f1);
			FileInputStream fis2=new FileInputStream(f2);

			SequenceInputStream sis=new SequenceInputStream(fis1,fis2);
			int c;
			while((c=sis.read())!=-1)
			{
			System.out.print((char)c);


			}
			sis.close();



	}




}
