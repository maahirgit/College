

import java.io.*;

class Sequenceinput
{
public static void main(String args[])
{
	try
	{
		
		FileInputStream fis1 = new FileInputStream("test1.dat");
		FileInputStream fis2 = new FileInputStream("test2.dat");

		SequenceInputStream sis = new SequenceInputStream(fis1,fis2);

		int c;
		//writing a file
		while((c = sis.read()) != -1)
		{
			System.out.print((char)c);
		}
		sis.close();
	}	
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
