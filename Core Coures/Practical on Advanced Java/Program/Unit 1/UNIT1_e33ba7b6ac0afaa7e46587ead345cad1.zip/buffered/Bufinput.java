/*THIS PROGRAMM SHOWS THE DEMO OF BUFFEREDINPUTSTREAM CLASS.
IT READ DATA FROM FILE (WITH THE USE OF FILE INPUTSTREAM) AND DISPLAY ON SCREEN*/


import java.io.*;

class Bufinput
{
	public static void main(String args[])
	{
		try
		{
			File f=new File("b2.dat");
			BufferedInputStream bufin=new BufferedInputStream(new FileInputStream(f));
			/*File f = new File("data.dat");
			FileInputStream fis=new FileInputStream(f);
			BufferedInputStream bufin = new BufferedInputStream(fis);*/

			int c;
			while((c=bufin.read()) != -1)
			{
				System.out.print((char)c);
			}
			bufin.close();
		}
		catch(IOException e)
		{	
			System.out.println("error");
		}
	}
}
