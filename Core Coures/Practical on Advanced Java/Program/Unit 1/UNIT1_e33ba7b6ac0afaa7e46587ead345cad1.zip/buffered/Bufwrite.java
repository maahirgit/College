/*THIS PROGRAMM SHOW THE DEMO OF BUFFEREDOUTPUTSTREAM CLASS.
IT WRITE STATIC DATA TO THE FILE WITH THE USE OF BUFFEREDOUTPUTSTREAM CLASS*/

import java.io.*;

class Bufwrite
{
public static void main(String args[])
{
	try
	{
		BufferedOutputStream busout = new BufferedOutputStream(new FileOutputStream("a2.dat"));
		String str="HelloWorld";
		for(int  x=10;x<=20;x++)
		{
		busout.write(x);
		}

		int len=str.length();
		byte b[]=new byte[len];
		b=str.getBytes();
		busout.write(b);
		busout.close();

		System.out.println("File Created");
	}	
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
