/* THIS PROGRAMME READ ONE FILE AND WRITE INTO SECOND FILE
IT SHOW THE USE OF FILEINPUTSTREAM AND FILEOUTPUTSTREAM CLASS
*/
import java.io.*;

class READ_FROM_TWO_FILE
{
	public static void main(String args[])
	{
		try
		{
			int c,d;
			FileInputStream fis = new FileInputStream("demo.dat");
			FileInputStream fis1 = new FileInputStream("Demo1.dat");
			FileOutputStream fos = new FileOutputStream("A5.dat");

			while((c = fis.read()) != -1)
			{
				fos.write(c);
				//System.out.print((char)c);
			}
			while((d = fis1.read()) != -1)
			{
				fos.write(d);
				//System.out.print((char)c);
			}
						
			fos.close();
			fis.close();
			fis1.close();

		}
		catch(IOException e)
		{	
			System.out.println(e);
		}
	}
}
