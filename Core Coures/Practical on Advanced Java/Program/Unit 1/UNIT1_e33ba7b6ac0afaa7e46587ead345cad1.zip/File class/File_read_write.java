
import java.io.*;

class File_read_write
{
	public static void main(String args[])
	{
		try
		{
			int c;
			File F=new File("abc.dat");
			FileInputStream fis = new FileInputStream(F);
			FileOutputStream fos = new FileOutputStream("f1.dat");

			while((c = fis.read()) != -1)
			{
				fos.write(c);
				//System.out.print((char)c);
			}
						
			fos.close();
			fis.close();

		}
		catch(IOException e)
		{	
			System.out.println("error");
		}
	}
}
