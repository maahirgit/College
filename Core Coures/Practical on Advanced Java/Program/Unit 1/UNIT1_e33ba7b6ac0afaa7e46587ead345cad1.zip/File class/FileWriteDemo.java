/* THIS PROGRMME  WRITE A CHARACTER (BETWEEN 65 TO 91) INTO FILE
IT GIVES THE DEMO OF FILEOUTPUTSTREAM CLASS*/
import java.io.*;

class FileWriteDemo
{
public static void main(String args[])
{
	try
	{
		
		FileOutputStream fos = new FileOutputStream("abc.dat");
		
		//writing a file
		for(int i =60 ;  i < 108 ; i++)
		{
			fos.write(i);
		}
		//fos.write('n');
		fos.close();

		System.out.println("File Created");
	}	
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
