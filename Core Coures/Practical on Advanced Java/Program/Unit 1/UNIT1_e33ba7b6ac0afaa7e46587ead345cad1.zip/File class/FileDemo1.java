

import java.io.*;
public class FileDemo1
{
   public static void main(String[] args)
   {
      File myFile = new File("/home/faculty/Desktop/adv_java/PROGRAMME/UNIT_1/");

      if(myFile.isDirectory())
      {
         	String str[]=myFile.list();
		for(int i=0;i<str.length;i++)
		{
		System.out.println(str[i]);		
		}
	}
}
}
