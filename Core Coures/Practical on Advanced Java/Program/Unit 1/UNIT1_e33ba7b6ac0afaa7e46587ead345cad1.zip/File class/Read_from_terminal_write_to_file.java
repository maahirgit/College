/* THIS PROGRAMME TAKE INPUT FROM KEYBOARD AND 
GIVE OUTPUT ON MONITOR. IT SHOW THE USE OF INPUTSTREAM AND OUTPUTSTREAM CLASS
*/

import java.io.*;
class Read
{
   public static void main(String[] args) 
   {
      
	int c;
	InputStream istream;
	istream = System.in;
		try
		{
			FileOutputStream fos = new FileOutputStream("karishma.dat");
	
			System.out.println("Type some characters ");
		
			while( (c= istream.read()) != 'A')
			{
				fos.write(c);
			}
			fos.close();
		}
		catch(IOException e)
		{
			System.out.println("Error: " + e.getMessage());
		}
		finally
		{
			try
			{
				istream.close();
				
			}
			catch (IOException e)
			{
				System.out.println("File did not close");
			}
		}
     }
}
